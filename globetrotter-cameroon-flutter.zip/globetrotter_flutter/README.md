# GlobeTrotter Cameroun — Version Flutter

Portage 1:1 en **Dart/Flutter** de l'application React (`globetrotter-cameroon`).
Même logique métier, mêmes écrans, mêmes couleurs, mêmes données mock — juste le
framework qui change (React/Tailwind → Flutter/Material).

## Ce qui a été porté

| React (web) | Flutter (mobile/desktop) |
|---|---|
| `App.tsx` (state global, toasts, routing par onglet) | `lib/main.dart` → `RootShell` |
| `types.ts` | `lib/models/models.dart` |
| `data/mockData.ts` | `lib/data/mock_data.dart` |
| `components/Navbar.tsx` | `lib/widgets/app_navbar.dart` |
| `components/BottomNav.tsx` | `lib/widgets/bottom_nav.dart` |
| `components/ExploreScreen.tsx` | `lib/screens/explore_screen.dart` |
| `components/TransitScreen.tsx` | `lib/screens/transit_screen.dart` |
| `components/FoodScreen.tsx` | `lib/screens/food_screen.dart` |
| `components/RegionsScreen.tsx` | `lib/screens/regions_screen.dart` |
| `components/JournalScreen.tsx` | `lib/screens/journal_screen.dart` |
| `components/WishlistScreen.tsx` | `lib/screens/wishlist_screen.dart` |
| `components/SafetyScreen.tsx` | `lib/screens/safety_screen.dart` |
| `components/ProfileScreen.tsx` | `lib/screens/profile_screen.dart` |
| `components/AuthModal.tsx` | `lib/modals/auth_modal.dart` |
| `components/PaymentModal.tsx` | `lib/modals/payment_modal.dart` |
| `components/AvailabilityModal.tsx` | `lib/modals/availability_modal.dart` |

Toute la logique métier a été conservée : filtres Explore (région / prix / recherche),
calculateur de transit, wishlist (ajout/suppression), carnet de voyage (création de
récits), simulation de paiement Orange Money / MTN MoMo en 3 étapes (formulaire →
décompte USSD → succès), SOS et appels d'urgence simulés, etc. L'appel au backend
Express (`fetch('/api/...')`) n'existant pas côté mobile, l'app démarre directement
avec les données mock — exactement le comportement du `catch` de secours déjà présent
dans le code React d'origine.

## Qualité des images ("net comme Pinterest")

Toutes les images passent par `HqNetworkImage` (`lib/widgets/hq_network_image.dart`) :
- mise en cache disque/mémoire (`cached_network_image`)
- forçage des paramètres Unsplash `q=90` (qualité) et une largeur adaptée à l'usage
  (`w=1200` pour les cartes, `w=1600` pour les bannières hero, `w=100-400` pour les
  avatars) via `hqImage()` dans `lib/theme/app_theme.dart`
- `FilterQuality.high` pour un rendu net à l'écran
- placeholder + fallback propre en cas d'échec réseau

## Lancer le projet

Le SDK Flutter n'est pas installé dans cet environnement d'exécution ; le code n'a
donc pas pu être compilé/testé ici. Pour le lancer chez vous :

```bash
# 1. Générer les dossiers de plateforme (android/ios/web/...) dans ce même dossier
flutter create . --project-name globetrotter_cameroon --org com.globetrotter.cameroon

# 2. Installer les dépendances
flutter pub get

# 3. Lancer sur un appareil/émulateur connecté
flutter run
```

> `flutter create .` ne touchera pas à `lib/`, `pubspec.yaml` ni `analysis_options.yaml`
> déjà présents — il ajoute uniquement les dossiers natifs manquants.

## Prochaines étapes possibles

- Brancher un vrai backend (remplacer les callbacks mock de `RootShell` par des
  appels `http`/`dio`).
- Ajouter `shared_preferences` pour persister wishlist / session utilisateur.
- Extraire `RootShell` vers un state manager (Provider/Riverpod) si l'app grossit.
