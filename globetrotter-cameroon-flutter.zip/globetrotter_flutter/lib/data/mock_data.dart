import '../models/models.dart';

final List<Destination> initialDestinations = [
  const Destination(
    id: 'dest-1',
    title: 'Les Gîtes de Kribi • Ocean Lodge',
    region: 'Sud',
    location: 'Kribi, Littoral Atlantique',
    pricePerNight: 145000,
    rating: 4.9,
    reviewCount: 128,
    imageUrl:
        'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=1200&q=85',
    badge: 'Coup de Cœur Heritage',
    description:
        "Surplombant l'Océan Atlantique et à proximité directe des uniques Chutes de la Lobé qui se jettent dans la mer. Suite privative en bois d'ébène avec terrasse panoramique.",
    amenities: [
      'Plage Privée',
      'Piscine Débordement',
      'Spa & Massage Eco',
      'Wi-Fi Haut Débit',
      'Restaurant Fruits de Mer'
    ],
    heritageSiteNearby: 'Chutes de la Lobé (1.2 km)',
    featured: true,
  ),
  const Destination(
    id: 'dest-2',
    title: 'Hilton Yaoundé Prestige Suite',
    region: 'Centre',
    location: 'Yaoundé Centre-Ville',
    pricePerNight: 120000,
    rating: 4.8,
    reviewCount: 215,
    imageUrl:
        'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=85',
    badge: 'Exclusivité Capitale',
    description:
        'Hôtel mythique situé en plein cœur de la capitale politique, offrant une vue imprenable sur les 7 collines de Yaoundé et un service 5 étoiles international.',
    amenities: [
      'Piscine Olympique',
      'Gym 24/7',
      'Service Limousine',
      'Bar Panoramique Le Safari'
    ],
    heritageSiteNearby: 'Musée National du Cameroun (500m)',
    featured: true,
  ),
  const Destination(
    id: 'dest-3',
    title: 'Mont Fébé Boutique Resort',
    region: 'Centre',
    location: 'Hauteurs de Mont Fébé, Yaoundé',
    pricePerNight: 95000,
    rating: 4.7,
    reviewCount: 94,
    imageUrl:
        'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=85',
    badge: 'Vue Panoramique',
    description:
        "Niché sur les hauteurs verdoyantes de Yaoundé avec un terrain de golf 18 trous et un air frais de montagne à 950 mètres d'altitude.",
    amenities: [
      'Golf 18 Trous',
      'Court de Tennis',
      'Jardins Botaniques',
      'Buffet Camerounais'
    ],
    heritageSiteNearby: 'Palais Congrès Yaoundé (2 km)',
  ),
  const Destination(
    id: 'dest-4',
    title: 'Éco-Lodge Rhumsiki & Kapsiki',
    region: 'Extrême-Nord',
    location: 'Rhumsiki, Monts Mandara',
    pricePerNight: 65000,
    rating: 4.9,
    reviewCount: 76,
    imageUrl:
        'https://images.unsplash.com/photo-1516426122078-c23e76319801?auto=format&fit=crop&w=1200&q=85',
    badge: 'Aventure Mystique',
    description:
        "Au pied du celebre Pic de Rhumsiki aux paysages lunaires sculptés par l'érosion volcanique. Dîner traditionnel sous le ciel étoilé du Sahel.",
    amenities: [
      'Randonnée Guidée',
      'Artisanat Local',
      'Cuisine de Terroir',
      "Terrasse d'Observation Celestial"
    ],
    heritageSiteNearby: 'Pic de Rhumsiki (300m)',
  ),
  const Destination(
    id: 'dest-5',
    title: 'Sawa Hotel Douala Waterfront',
    region: 'Littoral',
    location: 'Bonanjo, Douala',
    pricePerNight: 110000,
    rating: 4.6,
    reviewCount: 180,
    imageUrl:
        'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=1200&q=85',
    badge: 'Affaires & Détente',
    description:
        "Au cœur du quartier administratif de Douala, offrant un havre de paix tropical avec jardins luxuriants et piscine géante.",
    amenities: [
      'Piscine Lagoon',
      'Salles de Conférence',
      'Navette Aéroport',
      'Cuisine Sawa & Grill'
    ],
    heritageSiteNearby: 'Palais Dika Akwa (1.5 km)',
  ),
  const Destination(
    id: 'dest-6',
    title: 'Ranch de Ngaoundaba',
    region: 'Adamaoua',
    location: "Ngaoundéré, Falaise d'Adamaoua",
    pricePerNight: 75000,
    rating: 4.8,
    reviewCount: 62,
    imageUrl:
        'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=85',
    badge: 'Lac de Cratère',
    description:
        "Bordé par un lac de cratère sacré entouré de forêts primaires et de faune sauvage. L'expérience ultime de détente absolue.",
    amenities: ['Canoë Kayak', 'Observation des Oiseaux', 'Feu de Camp', 'Guides Safari'],
    heritageSiteNearby: 'Lac Cratère Ngaoundaba',
  ),
];

final List<RegionInfo> regionsData = [
  const RegionInfo(
    id: 'reg-centre',
    name: 'Centre',
    capital: 'Yaoundé',
    motto: 'Cœur Politique et Culturel des 7 Collines',
    description:
        "Le Centre abrite Yaoundé, la capitale aux sept collines. Région d'histoire, d'architecture coloniale, de monuments majestueux et de verdure luxuriante.",
    imageUrl:
        'https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=1200&q=85',
    highlights: ['Monument de la Réunification', 'Musée National', 'Parc de la Mefou', 'Mont Fébé'],
    climate: 'Tropical Équatorial (23°C - 28°C)',
    famousDish: 'Koki aux bananes plantains',
  ),
  const RegionInfo(
    id: 'reg-sud',
    name: 'Sud',
    capital: 'Ebolowa',
    motto: 'Plages Paradisiaques et Chutes Océaniques',
    description:
        "Célèbre pour Kribi et ses plages de sable fin bordées de cocotiers. La seule région où des cascades se jettent directement dans l'océan Atlantique.",
    imageUrl:
        'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=85',
    highlights: [
      'Chutes de la Lobé',
      'Plage de Grand Batanga',
      "Réserve de Campo Ma'an",
      'Rocher de Campo'
    ],
    climate: 'Chaud & Humide Atlantique (26°C - 31°C)',
    famousDish: 'Bar grillé aux épices locales & Crevettes Géantes',
  ),
  const RegionInfo(
    id: 'reg-littoral',
    name: 'Littoral',
    capital: 'Douala',
    motto: 'Poumon Économique et Berceau de la Culture Sawa',
    description:
        'Douala, métropole effervescente traversée par le fleuve Wouri. Capitale de la musique Makossa, de la haute finance et du festival Ngondo.',
    imageUrl:
        'https://images.unsplash.com/photo-1518684079-3c830dcef090?auto=format&fit=crop&w=1200&q=85',
    highlights: ['Pont sur le Wouri', 'Musée Maritime de Douala', 'Île aux Singes', 'Marché de la Cité'],
    climate: 'Tropical Humide (27°C - 33°C)',
    famousDish: 'Ndolé aux crevettes & Miondo',
  ),
  const RegionInfo(
    id: 'reg-ouest',
    name: 'Ouest',
    capital: 'Bafoussam',
    motto: 'Terre des Chefferies Traditionnelles et Hauts Plateaux',
    description:
        'Région montagneuse aux paysages saisissants, réputée pour la richesse de son artisanat, ses royaumes Bamiléké et Bamoun et ses lacs de cratère.',
    imageUrl:
        'https://images.unsplash.com/photo-1516426122078-c23e76319801?auto=format&fit=crop&w=1200&q=85',
    highlights: [
      'Palais Royal de Foumban',
      'Chutes de Mbouda',
      'Lac Baleng',
      'Musée des Civilisations Dschang'
    ],
    climate: 'Tempéré de Montagne (18°C - 24°C)',
    famousDish: 'Taro à la sauce jaune (Achu)',
  ),
  const RegionInfo(
    id: 'reg-sud-ouest',
    name: 'Sud-Ouest',
    capital: 'Buea',
    motto: 'Au Pied du Mont Cameroun et des Plages de Sable Noir',
    description:
        'Bordée par le sommet majestueux du Mont Cameroun (4 095m) et la ville côtière de Limbe connue pour son jardin botanique et son sable noir volcanique.',
    imageUrl:
        'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1200&q=85',
    highlights: ['Mont Cameroun', 'Jardin Botanique de Limbe', 'Centre de Primates', 'Sable Noir Seme Beach'],
    climate: 'Frais en altitude, Doux en côte (20°C - 27°C)',
    famousDish: 'Eru & Waterfufu',
  ),
  const RegionInfo(
    id: 'reg-extreme-nord',
    name: 'Extrême-Nord',
    capital: 'Maroua',
    motto: 'Magie des Monts Mandara et Safari Sauvage',
    description:
        'Mosaïque culturelle fascinante aux paysages sahéliens. Abrite le parc de Waza, les potiers de Rhumsiki et la cité royale de Rey Bouba.',
    imageUrl:
        'https://images.unsplash.com/photo-1547471080-7cc2caa01a7e?auto=format&fit=crop&w=1200&q=85',
    highlights: ['Parc National de Waza', 'Monts Mandara & Rhumsiki', 'Marché de Maroua', 'Dent de Mindif'],
    climate: 'Sahelien Sec & Ensoleillé (28°C - 38°C)',
    famousDish: 'Bouillie de Mil & Viande Séchée Kilichi',
  ),
  const RegionInfo(
    id: 'reg-adamaoua',
    name: 'Adamaoua',
    capital: 'Ngaoundéré',
    motto: "Château d'Eau du Cameroun et Plateaux d'Élevage",
    description:
        "Zone de transition entre la forêt équatoriale et le nord sahélien. Ses vallées abritent des sources d'eau minérale et de vastes pâturages.",
    imageUrl:
        'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=85',
    highlights: ['Chutes de Tello', 'Lac de Cratère Ngaoundaba', 'Palais du Lamido', 'Grottes de Mbang'],
    climate: 'Agréable & Venté (22°C - 28°C)',
    famousDish: 'Brochettes de Bœuf Capitaine & Lait Caillé Fresh',
  ),
  const RegionInfo(
    id: 'reg-nord',
    name: 'Nord',
    capital: 'Garoua',
    motto: 'Royaume des Hippopotames et de la Faune Sauvage',
    description:
        'Traversée par la Bénoué, la région du Nord abrite les plus grandes réserves de faune du pays et des barrages hydroélectriques monumentaux.',
    imageUrl:
        'https://images.unsplash.com/photo-1534567153574-2b12153a87f0?auto=format&fit=crop&w=1200&q=85',
    highlights: ['Parc National de la Bénoué', 'Barrage de Lagdo', 'Gorges de Kola', 'Lamidat de Garoua'],
    climate: 'Chaud & Ensoleillé (29°C - 36°C)',
    famousDish: 'Poisson Capitaine Fumé de la Bénoué',
  ),
  const RegionInfo(
    id: 'reg-est',
    name: 'Est',
    capital: 'Bertoua',
    motto: 'Sanctuaire de la Forêt Équatoriale et du Peuple Baka',
    description:
        "Immense tapis vert de forêts primaires préservées, patrie des traditions orales Baka et de la réserve de biosphère du Dja.",
    imageUrl:
        'https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=1200&q=85',
    highlights: ['Réserve de Biosphère du Dja', "Mines d'Or de Batouri", 'Campements Pygmées Baka'],
    climate: 'Équatorial Humide Luxuriant (24°C - 29°C)',
    famousDish: 'Kanga grillé aux graines de courge (Nkui)',
  ),
  const RegionInfo(
    id: 'reg-nord-ouest',
    name: 'Nord-Ouest',
    capital: 'Bamenda',
    motto: 'Paysage de Collines et Palais des Fon',
    description:
        'Célèbre pour la Ring Road panoramique, le lac Oku, ses chefferies séculaires et son textile traditionnel Ndop tissé main.',
    imageUrl:
        'https://images.unsplash.com/photo-1511884642898-4c92249e20b6?auto=format&fit=crop&w=1200&q=85',
    highlights: ['Palais du Fon de Bafut', 'Lac Oku', 'Mont Oku', 'Ring Road Panoramique'],
    climate: 'Frais de Montagne (16°C - 23°C)',
    famousDish: "Kati Kati (Poulet Fumé à l'Huile de Palme & Ugali)",
  ),
];

final List<Dish> dishesData = [
  const Dish(
    id: 'dish-1',
    title: 'Ndolé Royal aux Crevettes & Miondo',
    region: 'Littoral (Sawa)',
    category: DishCategory.traditionnel,
    priceXAF: 5500,
    prepTimeMinutes: 45,
    rating: 5.0,
    imageUrl:
        'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=1200&q=85',
    description:
        "Le plat national emblématique du Cameroun. Feuilles de ndolé lavées à la perfection, mijotées dans une pâte d'arachides fraîches sautées à l'ail, aux écrevisses et garnies de grosses crevettes de Kribi.",
    ingredients: [
      'Feuilles de Ndolé',
      'Arachides Blanches',
      'Crevettes Royales',
      'Écrevisses',
      'Ail & Oignons',
      'Bâtons de Manioc Miondo'
    ],
  ),
  const Dish(
    id: 'dish-2',
    title: 'Poulet DG Luxe (Directeur Général)',
    region: 'Centre / National',
    category: DishCategory.moderneFusion,
    priceXAF: 4800,
    prepTimeMinutes: 35,
    rating: 4.9,
    imageUrl:
        'https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?auto=format&fit=crop&w=1200&q=85',
    description:
        'Incontournable des grandes réceptions. Morceaux de poulet fermier frits, mijotés dans une brunoise colorée de bananes plantains mûres, poivrons rouges, carottes, haricots verts et condiments du terroir.',
    ingredients: [
      'Poulet Fermier',
      'Bananes Plantains Mûres',
      'Poivrons Trio',
      'Carottes Crisp',
      'Poivre de Penja'
    ],
  ),
  const Dish(
    id: 'dish-3',
    title: 'Soupe Achu Jaune & Peau de Bœuf',
    region: 'Ouest / Nord-Ouest',
    category: DishCategory.traditionnel,
    priceXAF: 4000,
    prepTimeMinutes: 40,
    rating: 4.8,
    imageUrl:
        'https://images.unsplash.com/photo-1547592166-23ac45744acd?auto=format&fit=crop&w=1200&q=85',
    description:
        "Pâte de taro pilé servie en puits au centre duquel est versée une sauce jaune veloutée préparée avec de l'huile de palme, du kanwa et un savant mélange de 15 épices traditionnelles.",
    ingredients: ['Taro Pilé', 'Sauce Jaune Épicée', 'Peau de Bœuf (Kanda)', 'Tripes', 'Huile de Palme Purifiée'],
  ),
  const Dish(
    id: 'dish-4',
    title: 'Bayangi Eru & Fufu de Manioc',
    region: 'Sud-Ouest',
    category: DishCategory.traditionnel,
    priceXAF: 4500,
    prepTimeMinutes: 50,
    rating: 4.9,
    imageUrl:
        'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=1200&q=85',
    description:
        "Feuilles d'eru finement hachées avec des feuilles de waterleaf, mijotées longuement avec de la peau de bœuf fumée, poisson séché, viande de brousse et une touche généreuse d'huile de palme rouge.",
    ingredients: ["Feuilles d'Eru", 'Waterleaf', 'Peau de Bœuf Fumé', 'Poisson Séché', 'Fufu de Manioc Fresh'],
  ),
  const Dish(
    id: 'dish-5',
    title: 'Koki Ancestral en Feuille de Bananier',
    region: 'Centre / Ouest',
    category: DishCategory.traditionnel,
    priceXAF: 3200,
    prepTimeMinutes: 60,
    rating: 4.7,
    imageUrl:
        'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=1200&q=85',
    description:
        "Gâteau de haricots d'œil noir écrasés, émulsionné avec de l'huile de palme vierge et cuit doucement à la vapeur dans des feuilles de bananier flambées. Accompagné de bananes ou de patates douces.",
    ingredients: ["Haricots d'Œil Noir", 'Huile de Palme Rouge', 'Piment Oiselet', 'Feuilles de Bananier Steam'],
  ),
  const Dish(
    id: 'dish-6',
    title: 'Bar de Kribi Grillé au Poivre de Penja',
    region: 'Sud (Kribi)',
    category: DishCategory.moderneFusion,
    priceXAF: 8500,
    prepTimeMinutes: 30,
    rating: 5.0,
    imageUrl:
        'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?auto=format&fit=crop&w=1200&q=85',
    description:
        "Bar entier de l'Océan Atlantique, mariné avec le mondialement célèbre Poivre Blanc de Penja IGP, gingembre sauvage et rondelles, braisé au feu de bois.",
    ingredients: ['Bar Frais de Kribi', 'Poivre Blanc de Penja IGP', 'Gingembre & Djansang', 'Frites de Plantain'],
  ),
];

final List<JournalPost> journalPosts = [
  const JournalPost(
    id: 'j-1',
    title: "Les Spirales de l'Histoire au Monument de la Réunification",
    location: 'Yaoundé, Région du Centre',
    date: '14 Octobre 2025',
    author: 'Marcelle N.',
    authorRole: 'Photographe & Raconteuse de Patrimoine',
    authorAvatar:
        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    coverImage:
        'https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=1200&q=85',
    excerpt:
        "Au lever du soleil, l'œuvre monumentale signée Armand Augustin Lisot se dresse fièrement contre les brumes du Mont Fébé.",
    content:
        "Gravir les marches du Monument de la Réunification à Yaoundé à six heures du matin offre une expérience visuelle mémorable. Deux serpents enlacés s'élèvent vers le ciel, symbolisant la fusion du Cameroun oriental et occidental. Le silence qui règne autour du parc est seulement interrompu par le chant des passereaux tropicaux. La lumière dorée caresse les bas-reliefs en bronze sculptés avec une finesse impressionnante.",
    likes: 342,
    commentsCount: 28,
  ),
  const JournalPost(
    id: 'j-2',
    title: "L'Éveil du Parc National de Waza",
    location: 'Waza, Extrême-Nord',
    date: '02 Novembre 2025',
    author: 'Ibrahim O.',
    authorRole: 'Naturaliste & Guide Safari',
    authorAvatar:
        'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
    coverImage:
        'https://images.unsplash.com/photo-1516426122078-c23e76319801?auto=format&fit=crop&w=1200&q=85',
    excerpt:
        "Quand la poussière d'or du Sahel rencontre la silhouette majestueuse d'un troupeau d'éléphants au marigot.",
    content:
        "La traversée du parc de Waza en Toyota Land Cruiser au crépuscule est magique. Des girafes de Kordofan étirent leurs necks gracieux au-dessus des acacias. Près de la mare de Tchatibali, des centaines d'oiseaux migrateurs s'envolent à notre approche dans un concert de couleurs vibrantes. Un moment suspendu dans le temps.",
    likes: 512,
    commentsCount: 45,
  ),
  const JournalPost(
    id: 'j-3',
    title: 'Chariot des Dieux: Ascension du Mont Cameroun',
    location: 'Buea, Sud-Ouest',
    date: '18 Décembre 2025',
    author: 'Marcelle N.',
    authorRole: 'Exploratrice de Sommets',
    authorAvatar:
        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    coverImage:
        'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1200&q=85',
    excerpt:
        "À 4 095 mètres au-dessus des nuages, contempler le soleil se lever sur l'océan Atlantique et les côtes du Nigeria.",
    content:
        "Quitter Buea sous la fraîcheur matinale pour atteindre la Cabane 1, puis la Cabane 2 à travers la forêt de montagne et les savanes d'altitude. La terre volcanique encore chaude par endroits rappelle que le dieu de la montagne, Efasa Moto, protège toujours ces lieux mystiques.",
    likes: 620,
    commentsCount: 52,
  ),
];

final List<WishlistItem> initialWishlist = [
  const WishlistItem(
    id: 'wish-1',
    title: 'Monument de la Réunification',
    type: WishlistType.monument,
    location: 'Yaoundé, Centre',
    imageUrl:
        'https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=1200&q=85',
    addedAt: 'Hier',
    rating: 4.9,
  ),
  const WishlistItem(
    id: 'wish-2',
    title: 'Chutes de la Lobé & Plage',
    type: WishlistType.destination,
    location: 'Kribi, Sud',
    imageUrl:
        'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=85',
    addedAt: 'Il y a 3 jours',
    rating: 5.0,
  ),
  const WishlistItem(
    id: 'wish-3',
    title: 'Palais Royal de Foumban',
    type: WishlistType.monument,
    location: 'Foumban, Ouest',
    imageUrl:
        'https://images.unsplash.com/photo-1516426122078-c23e76319801?auto=format&fit=crop&w=1200&q=85',
    addedAt: 'La semaine dernière',
    rating: 4.8,
  ),
];

final List<EmergencyContact> emergencyContacts = [
  const EmergencyContact(
    id: 'emer-1',
    name: 'Police Secours',
    number: '117',
    type: EmergencyType.police,
    description: "Intervention d'urgence, sécurité publique et assistance immédiate 24/7.",
  ),
  const EmergencyContact(
    id: 'emer-2',
    name: 'Sapeurs-Pompiers',
    number: '118',
    type: EmergencyType.pompiers,
    description: 'Incendies, désincarceration, secours routier et catastrophes naturelles.',
  ),
  const EmergencyContact(
    id: 'emer-3',
    name: 'SAMU Urgence Médicale',
    number: '119',
    type: EmergencyType.samu,
    description: 'Urgences vitales, ambulances médicalisées et régulation médicale.',
  ),
  const EmergencyContact(
    id: 'emer-4',
    name: 'Gendarmerie Nationale',
    number: '113',
    type: EmergencyType.dispatch,
    description: 'Postes de contrôle routier, sécurité interurbaine et patrouilles.',
  ),
];

final List<HealthCenter> healthCenters = [
  const HealthCenter(
    id: 'hc-1',
    name: 'Hôpital Central de Yaoundé',
    distanceKm: 0.8,
    status: 'Open 24/7',
    phone: '+237 222 23 40 20',
    address: 'Avenue Henri Dunant, Yaoundé',
  ),
  const HealthCenter(
    id: 'hc-2',
    name: 'Clinique Médicale de la Paix',
    distanceKm: 1.4,
    status: 'Open Now',
    phone: '+237 222 20 15 88',
    address: 'Bastos, face Ambassade de France, Yaoundé',
  ),
  const HealthCenter(
    id: 'hc-3',
    name: 'Centre Hospitalier Universitaire (CHU)',
    distanceKm: 3.2,
    status: 'Open 24/7',
    phone: '+237 222 23 00 11',
    address: 'Melen, Yaoundé',
  ),
];

final List<SafetyAlert> safetyAlerts = [
  const SafetyAlert(
    id: 'alert-1',
    type: SafetyAlertType.warning,
    title: 'Avertissement Météo • Pluies Diluviennes',
    description:
        'Vigilance forte pluies de saison sur l\'axe Yaoundé-Douala. Ralentissement conseillé pour le transit routier.',
    timeAgo: 'Il y a 25 minutes',
  ),
  const SafetyAlert(
    id: 'alert-2',
    type: SafetyAlertType.info,
    title: 'Conseil Santé • Carnet de Vaccination',
    description:
        "Présentation du carnet de vaccination Fièvre Jaune recommandée aux points de contrôle d'entrée du parc Waza.",
    timeAgo: 'Il y a 2 heures',
  ),
];

const UserProfile userProfileMock = UserProfile(
  id: 'usr-884',
  name: 'Marcelle Nkem',
  handle: '@marcelle_trotter',
  avatarUrl:
      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=85',
  bio:
      'Collectionneuse de moments et de récits à travers les 10 régions du Cameroun. Passionnée par le patrimoine Bamiléké et la côte Sawa.',
  statusTier: 'Voyageur Émérite OR 🏆',
  countriesVisited: 14,
  distanceKm: 12450,
  memoriesSaved: 842,
);

/// Villes disponibles pour le calculateur de transit (TransitScreen)
const List<String> transitCityOptions = [
  'Yaoundé Mvan',
  'Yaoundé Centre-Ville',
  'Douala Akwa',
  'Douala Bonanjo',
  'Kribi Tara Plage',
  'Bafoussam Centre',
  'Buea Town',
  'Limbe Botanic',
  'Garoua Centre',
  'Ngaoundéré Gare',
];
