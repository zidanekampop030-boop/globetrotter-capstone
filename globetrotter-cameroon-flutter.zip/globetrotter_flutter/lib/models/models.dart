// Modèles de données — équivalent direct de src/types.ts

class Destination {
  final String id;
  final String title;
  final String region;
  final String location;
  final int pricePerNight;
  final double rating;
  final int reviewCount;
  final String imageUrl;
  final String? badge;
  final String description;
  final List<String> amenities;
  final String? heritageSiteNearby;
  final bool featured;

  const Destination({
    required this.id,
    required this.title,
    required this.region,
    required this.location,
    required this.pricePerNight,
    required this.rating,
    required this.reviewCount,
    required this.imageUrl,
    this.badge,
    required this.description,
    required this.amenities,
    this.heritageSiteNearby,
    this.featured = false,
  });
}

enum TransitMode { taxi, moto, bus, train }

extension TransitModeX on TransitMode {
  String get label {
    switch (this) {
      case TransitMode.taxi:
        return 'TAXI';
      case TransitMode.moto:
        return 'MOTO';
      case TransitMode.bus:
        return 'BUS';
      case TransitMode.train:
        return 'TRAIN';
    }
  }
}

class TransitRoute {
  final String origin;
  final String destination;
  final TransitMode mode;
  final int minFareXAF;
  final int maxFareXAF;
  final int estimatedMinutes;
  final String tips;

  const TransitRoute({
    required this.origin,
    required this.destination,
    required this.mode,
    required this.minFareXAF,
    required this.maxFareXAF,
    required this.estimatedMinutes,
    required this.tips,
  });
}

class RegionInfo {
  final String id;
  final String name;
  final String capital;
  final String motto;
  final String description;
  final String imageUrl;
  final List<String> highlights;
  final String climate;
  final String famousDish;

  const RegionInfo({
    required this.id,
    required this.name,
    required this.capital,
    required this.motto,
    required this.description,
    required this.imageUrl,
    required this.highlights,
    required this.climate,
    required this.famousDish,
  });
}

enum DishCategory { traditionnel, moderneFusion }

extension DishCategoryX on DishCategory {
  String get label => this == DishCategory.traditionnel
      ? 'Traditionnel'
      : 'Moderne / Fusion';
}

class Dish {
  final String id;
  final String title;
  final String region;
  final DishCategory category;
  final int priceXAF;
  final int prepTimeMinutes;
  final double rating;
  final String imageUrl;
  final String description;
  final List<String> ingredients;

  const Dish({
    required this.id,
    required this.title,
    required this.region,
    required this.category,
    required this.priceXAF,
    required this.prepTimeMinutes,
    required this.rating,
    required this.imageUrl,
    required this.description,
    required this.ingredients,
  });
}

class JournalPost {
  final String id;
  final String title;
  final String location;
  final String date;
  final String author;
  final String authorRole;
  final String authorAvatar;
  final String coverImage;
  final String excerpt;
  final String content;
  final int likes;
  final int commentsCount;

  const JournalPost({
    required this.id,
    required this.title,
    required this.location,
    required this.date,
    required this.author,
    required this.authorRole,
    required this.authorAvatar,
    required this.coverImage,
    required this.excerpt,
    required this.content,
    required this.likes,
    required this.commentsCount,
  });
}

enum WishlistType { destination, region, food, monument }

extension WishlistTypeX on WishlistType {
  String get label {
    switch (this) {
      case WishlistType.destination:
        return 'DESTINATION';
      case WishlistType.region:
        return 'REGION';
      case WishlistType.food:
        return 'FOOD';
      case WishlistType.monument:
        return 'MONUMENT';
    }
  }
}

class WishlistItem {
  final String id;
  final String title;
  final WishlistType type;
  final String location;
  final String imageUrl;
  final String addedAt;
  final double? rating;

  const WishlistItem({
    required this.id,
    required this.title,
    required this.type,
    required this.location,
    required this.imageUrl,
    required this.addedAt,
    this.rating,
  });
}

enum EmergencyType { police, pompiers, samu, dispatch }

class EmergencyContact {
  final String id;
  final String name;
  final String number;
  final EmergencyType type;
  final String description;

  const EmergencyContact({
    required this.id,
    required this.name,
    required this.number,
    required this.type,
    required this.description,
  });
}

class HealthCenter {
  final String id;
  final String name;
  final double distanceKm;
  final String status;
  final String phone;
  final String address;

  const HealthCenter({
    required this.id,
    required this.name,
    required this.distanceKm,
    required this.status,
    required this.phone,
    required this.address,
  });
}

enum SafetyAlertType { warning, info, success }

class SafetyAlert {
  final String id;
  final SafetyAlertType type;
  final String title;
  final String description;
  final String timeAgo;

  const SafetyAlert({
    required this.id,
    required this.type,
    required this.title,
    required this.description,
    required this.timeAgo,
  });
}

enum PaymentOperator { orangeMoney, mtnMomo }

class UserProfile {
  final String id;
  final String name;
  final String handle;
  final String avatarUrl;
  final String bio;
  final String statusTier;
  final int countriesVisited;
  final int distanceKm;
  final int memoriesSaved;

  const UserProfile({
    required this.id,
    required this.name,
    required this.handle,
    required this.avatarUrl,
    required this.bio,
    required this.statusTier,
    required this.countriesVisited,
    required this.distanceKm,
    required this.memoriesSaved,
  });
}

/// Item générique passé aux flux de paiement / réservation
/// (équivalent du type inline { title, priceXAF, imageUrl } côté React)
class PayableItem {
  final String title;
  final int priceXAF;
  final String? imageUrl;

  const PayableItem({required this.title, required this.priceXAF, this.imageUrl});
}
