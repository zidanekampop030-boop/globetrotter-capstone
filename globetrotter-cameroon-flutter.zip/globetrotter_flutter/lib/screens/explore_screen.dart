import 'package:flutter/material.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import '../utils/formatters.dart';
import '../widgets/hq_network_image.dart';

class ExploreScreen extends StatefulWidget {
  final List<Destination> destinations;
  final List<String> wishlistIds;
  final ValueChanged<Destination> onToggleWishlist;
  final ValueChanged<PayableItem> onBookNow;
  final VoidCallback onOpenAvailabilityModal;

  const ExploreScreen({
    super.key,
    required this.destinations,
    required this.wishlistIds,
    required this.onToggleWishlist,
    required this.onBookNow,
    required this.onOpenAvailabilityModal,
  });

  @override
  State<ExploreScreen> createState() => _ExploreScreenState();
}

class _ExploreScreenState extends State<ExploreScreen> {
  String selectedRegion = 'All';
  double maxPrice = 200000;
  String searchQuery = '';

  static const regionsList = ['All', 'Centre', 'Sud', 'Littoral', 'Ouest', 'Extrême-Nord', 'Adamaoua'];

  List<Destination> get filtered {
    return widget.destinations.where((d) {
      final matchRegion = selectedRegion == 'All' ||
          d.region.toLowerCase() == selectedRegion.toLowerCase();
      final matchPrice = d.pricePerNight <= maxPrice;
      final q = searchQuery.toLowerCase();
      final matchSearch = d.title.toLowerCase().contains(q) || d.location.toLowerCase().contains(q);
      return matchRegion && matchPrice && matchSearch;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final crossAxisCount = width >= 1100 ? 3 : (width >= 700 ? 2 : 1);

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _heroBanner(),
          const SizedBox(height: 24),
          _filterToolbar(),
          const SizedBox(height: 24),
          _resultsHeader(),
          const SizedBox(height: 16),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: filtered.length,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: crossAxisCount,
              mainAxisSpacing: 20,
              crossAxisSpacing: 20,
              childAspectRatio: 0.72,
            ),
            itemBuilder: (context, i) => _destinationCard(filtered[i]),
          ),
          const SizedBox(height: 24),
          _kribiBanner(),
        ],
      ),
    );
  }

  Widget _heroBanner() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(color: AppColors.border),
          borderRadius: BorderRadius.circular(24),
        ),
        child: Stack(
          children: [
            SizedBox(
              height: 380,
              width: double.infinity,
              child: HqNetworkImage(
                url:
                    'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=1600&q=85',
                width: 1600,
              ),
            ),
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                    colors: [AppColors.bg.withOpacity(0.95), AppColors.bg.withOpacity(0.55), Colors.transparent],
                  ),
                ),
              ),
            ),
            Positioned(
              left: 20,
              right: 20,
              bottom: 20,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: AppColors.accentDeep.withOpacity(0.4),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: AppColors.accent.withOpacity(0.4)),
                    ),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.auto_awesome, size: 13, color: AppColors.gold),
                      const SizedBox(width: 6),
                      Text('EXCLUSIVE DESTINATIONS • 2026 EDITION',
                          style: AppTheme.sans(fontSize: 10, fontWeight: FontWeight.w700, color: AppColors.accent)),
                    ]),
                  ),
                  const SizedBox(height: 10),
                  Text('Hébergements de Prestige & Patrimoine du Cameroun',
                      style: AppTheme.serif(fontSize: 24, height: 1.15)),
                  const SizedBox(height: 10),
                  Text(
                    "Réservez des villas océaniques, suites panoramiques et éco-lodges situés à deux pas des monuments historiques et des réserves naturelles.",
                    style: AppTheme.sans(fontSize: 12, color: AppColors.textPrimary.withOpacity(0.9), height: 1.4),
                  ),
                  const SizedBox(height: 16),
                  Wrap(spacing: 10, runSpacing: 10, children: [
                    ElevatedButton.icon(
                      onPressed: widget.onOpenAvailabilityModal,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.accent,
                        foregroundColor: AppColors.bg,
                        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      ),
                      icon: const Icon(Icons.calendar_today, size: 16),
                      label: Text('Vérifier la Disponibilité',
                          style: AppTheme.sans(fontSize: 12, fontWeight: FontWeight.bold, color: AppColors.bg)),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                      decoration: BoxDecoration(
                        color: AppColors.surfaceAlt.withOpacity(0.8),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: AppColors.borderStrong),
                      ),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        const Icon(Icons.verified_user, size: 15, color: AppColors.accent),
                        const SizedBox(width: 6),
                        Text('Paiement Sécurisé Orange & MTN MoMo', style: AppTheme.sans(fontSize: 11)),
                      ]),
                    ),
                  ]),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _filterToolbar() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Search
          Container(
            decoration: BoxDecoration(
              color: AppColors.bg,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.border),
            ),
            child: TextField(
              style: AppTheme.sans(fontSize: 12, color: Colors.white),
              onChanged: (v) => setState(() => searchQuery = v),
              decoration: InputDecoration(
                hintText: 'Rechercher Kribi, Yaoundé, Lodge...',
                hintStyle: AppTheme.sans(fontSize: 12, color: AppColors.textMuted),
                prefixIcon: const Icon(Icons.search, size: 18, color: AppColors.textMuted),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(vertical: 12),
              ),
            ),
          ),
          const SizedBox(height: 12),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: regionsList.map((r) {
                final isSelected = selectedRegion == r;
                return Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: ChoiceChip(
                    label: Text(r == 'All' ? 'Toutes les Régions' : r),
                    selected: isSelected,
                    onSelected: (_) => setState(() => selectedRegion = r),
                    labelStyle: AppTheme.sans(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: isSelected ? AppColors.bg : AppColors.textMuted,
                    ),
                    backgroundColor: AppColors.surfaceChip,
                    selectedColor: AppColors.accent,
                    side: BorderSide(color: isSelected ? Colors.transparent : AppColors.border),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 12),
          const Divider(color: AppColors.border, height: 1),
          const SizedBox(height: 12),
          Row(children: [
            const Icon(Icons.tune, size: 15, color: AppColors.accent),
            const SizedBox(width: 8),
            Text('Budget max/nuit: ', style: AppTheme.sans(fontSize: 11, color: AppColors.textMuted)),
            Text('${formatXAF(maxPrice)} XAF',
                style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.gold)),
          ]),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: AppColors.accent,
              inactiveTrackColor: AppColors.border,
              thumbColor: AppColors.accent,
              overlayColor: AppColors.accent.withOpacity(0.2),
              trackHeight: 3,
            ),
            child: Slider(
              min: 50000,
              max: 200000,
              divisions: 15,
              value: maxPrice,
              onChanged: (v) => setState(() => maxPrice = v),
            ),
          ),
        ],
      ),
    );
  }

  Widget _resultsHeader() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Text('Hébergements Sélectionnés', style: AppTheme.serif(fontSize: 19)),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(20)),
                  child: Text('${filtered.length} disponibles',
                      style: AppTheme.sans(fontSize: 10, color: AppColors.accent)),
                ),
              ]),
              const SizedBox(height: 4),
              Text('Profitez des tarifs négociés en direct avec les éco-lodges camerounais',
                  style: AppTheme.sans(fontSize: 11, color: AppColors.textMuted)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _destinationCard(Destination dest) {
    final isWishlisted = widget.wishlistIds.contains(dest.id);
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: isWishlisted ? AppColors.accent.withOpacity(0.3) : AppColors.border),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          AspectRatio(
            aspectRatio: 16 / 10,
            child: Stack(
              fit: StackFit.expand,
              children: [
                HqNetworkImage(url: dest.imageUrl),
                if (dest.badge != null)
                  Positioned(
                    top: 10,
                    left: 10,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: AppColors.bg.withOpacity(0.8),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: AppColors.gold.withOpacity(0.4)),
                      ),
                      child: Text(dest.badge!,
                          style: AppTheme.sans(fontSize: 10, fontWeight: FontWeight.w600, color: AppColors.gold)),
                    ),
                  ),
                Positioned(
                  top: 10,
                  right: 10,
                  child: GestureDetector(
                    onTap: () => widget.onToggleWishlist(dest),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: isWishlisted ? Colors.red.shade500 : AppColors.bg.withOpacity(0.6),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        isWishlisted ? Icons.favorite : Icons.favorite_border,
                        size: 15,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
                Positioned(
                  bottom: 10,
                  left: 10,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.bg.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.star, size: 12, color: AppColors.gold),
                      const SizedBox(width: 4),
                      Text('${dest.rating}',
                          style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.white)),
                      const SizedBox(width: 3),
                      Text('(${dest.reviewCount})', style: AppTheme.sans(fontSize: 10, color: AppColors.textMuted)),
                    ]),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(children: [
                        const Icon(Icons.location_on, size: 12, color: AppColors.accent),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(dest.location,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.accent)),
                        ),
                      ]),
                      const SizedBox(height: 6),
                      Text(dest.title,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: AppTheme.serif(fontSize: 15, height: 1.2)),
                      const SizedBox(height: 6),
                      Text(dest.description,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: AppTheme.sans(fontSize: 11, color: AppColors.textMuted, height: 1.35)),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 10),
                      const Divider(color: AppColors.border, height: 1),
                      const SizedBox(height: 10),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('TARIF / NUIT',
                                  style: AppTheme.sans(fontSize: 9, color: AppColors.textMuted)),
                              Text('${formatXAF(dest.pricePerNight)} XAF',
                                  style: AppTheme.sans(fontSize: 14, fontWeight: FontWeight.bold, color: AppColors.accent)),
                            ],
                          ),
                          ElevatedButton(
                            onPressed: () => widget.onBookNow(PayableItem(
                              title: dest.title,
                              priceXAF: dest.pricePerNight,
                              imageUrl: dest.imageUrl,
                            )),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.accent,
                              foregroundColor: AppColors.bg,
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            ),
                            child: Text('Réserver',
                                style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.bg)),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _kribiBanner() {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.accentDeep.withOpacity(0.4)),
        gradient: LinearGradient(
          colors: [AppColors.accentDeep.withOpacity(0.3), AppColors.surface],
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('LA COLLECTION KRIBI & OCÉAN',
              style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.gold)),
          const SizedBox(height: 6),
          Text('Découvrez la magie des Chutes de la Lobé à marée haute', style: AppTheme.serif(fontSize: 17)),
          const SizedBox(height: 8),
          Text(
            "Profitez de nos offres combinées hébergement + excursion pirogue traditionnelle avec des guides assermentés de la côte Sawa.",
            style: AppTheme.sans(fontSize: 11, color: AppColors.textMuted, height: 1.4),
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: () => setState(() {
              selectedRegion = 'Sud';
              searchQuery = 'Kribi';
            }),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.gold,
              foregroundColor: AppColors.bg,
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            ),
            child: Text('Explorer la Côte Sawa',
                style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.bg)),
          ),
        ],
      ),
    );
  }
}
