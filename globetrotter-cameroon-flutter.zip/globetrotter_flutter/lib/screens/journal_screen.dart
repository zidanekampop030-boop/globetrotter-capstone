import 'package:flutter/material.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import '../widgets/hq_network_image.dart';

class NewJournalEntry {
  final String title;
  final String location;
  final String content;
  final String? coverImage;
  NewJournalEntry({required this.title, required this.location, required this.content, this.coverImage});
}

class JournalScreen extends StatefulWidget {
  final List<JournalPost> posts;
  final ValueChanged<NewJournalEntry> onAddPost;

  const JournalScreen({super.key, required this.posts, required this.onAddPost});

  @override
  State<JournalScreen> createState() => _JournalScreenState();
}

class _JournalScreenState extends State<JournalScreen> {
  bool isAddModalOpen = false;
  final _titleCtrl = TextEditingController();
  final _locationCtrl = TextEditingController();
  final _contentCtrl = TextEditingController();
  final _coverCtrl = TextEditingController();
  final Set<String> likedPostIds = {};

  void _createPost() {
    if (_titleCtrl.text.isNotEmpty && _contentCtrl.text.isNotEmpty) {
      widget.onAddPost(NewJournalEntry(
        title: _titleCtrl.text,
        location: _locationCtrl.text,
        content: _contentCtrl.text,
        coverImage: _coverCtrl.text.isEmpty ? null : _coverCtrl.text,
      ));
      _titleCtrl.clear();
      _locationCtrl.clear();
      _contentCtrl.clear();
      _coverCtrl.clear();
      setState(() => isAddModalOpen = false);
    }
  }

  void _toggleLike(String id) {
    setState(() {
      if (likedPostIds.contains(id)) {
        likedPostIds.remove(id);
      } else {
        likedPostIds.add(id);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _header(),
              const SizedBox(height: 20),
              _quoteBanner(),
              const SizedBox(height: 20),
              ...widget.posts.map((p) => Padding(padding: const EdgeInsets.only(bottom: 20), child: _postCard(p))),
            ],
          ),
        ),
        if (isAddModalOpen) _addModal(),
      ],
    );
  }

  Widget _header() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(22), border: Border.all(color: AppColors.border)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            const Icon(Icons.menu_book_outlined, size: 15, color: AppColors.accent),
            const SizedBox(width: 6),
            Expanded(
              child: Text('CAMEROON ARCHIVES • CARNET DE VOYAGE',
                  style: AppTheme.sans(fontSize: 10, fontWeight: FontWeight.bold, color: AppColors.accent)),
            ),
          ]),
          const SizedBox(height: 8),
          Text('Récits, Mémoires & Photographies', style: AppTheme.serif(fontSize: 19)),
          const SizedBox(height: 6),
          Text('Partagez vos escapades à travers le Cameroun et conservez vos plus beaux souvenirs de route.',
              style: AppTheme.sans(fontSize: 11.5, color: AppColors.textMuted, height: 1.4)),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () => setState(() => isAddModalOpen = true),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.accent,
                foregroundColor: AppColors.bg,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
              icon: const Icon(Icons.add, size: 16),
              label: Text('NOUVELLE ENTRÉE', style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.bg)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _quoteBanner() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppColors.gold.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          const Icon(Icons.auto_awesome, size: 18, color: AppColors.gold),
          const SizedBox(height: 8),
          Text(
            "« Le Cameroun est l'Afrique en miniature non seulement par ses paysages, mais surtout par la richesse d'âme de ses peuples. »",
            textAlign: TextAlign.center,
            style: AppTheme.serif(fontSize: 13, fontWeight: FontWeight.normal, fontStyle: FontStyle.italic, color: AppColors.gold, height: 1.4),
          ),
        ],
      ),
    );
  }

  Widget _postCard(JournalPost post) {
    final isLiked = likedPostIds.contains(post.id);
    final currentLikes = post.likes + (isLiked ? 1 : 0);

    return Container(
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(22), border: Border.all(color: AppColors.border)),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 18, 18, 0),
            child: Row(
              children: [
                ClipOval(child: SizedBox(width: 38, height: 38, child: HqNetworkImage(url: post.authorAvatar, width: 100))),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(post.author, style: AppTheme.sans(fontSize: 12.5, fontWeight: FontWeight.bold, color: Colors.white)),
                      Text(post.authorRole, style: AppTheme.sans(fontSize: 10.5, color: AppColors.textMuted)),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Row(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.location_on, size: 12, color: AppColors.accent),
                      const SizedBox(width: 3),
                      Text(post.location, style: AppTheme.sans(fontSize: 10.5, color: AppColors.textMuted)),
                    ]),
                    Text(post.date, style: AppTheme.sans(fontSize: 10, color: AppColors.textMuted)),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          AspectRatio(aspectRatio: 21 / 9, child: HqNetworkImage(url: post.coverImage)),
          Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(post.title, style: AppTheme.serif(fontSize: 18, height: 1.2)),
                const SizedBox(height: 8),
                Text(post.content, style: AppTheme.sans(fontSize: 12, color: AppColors.textPrimary.withOpacity(0.9), height: 1.5)),
                const SizedBox(height: 14),
                const Divider(color: AppColors.border, height: 1),
                const SizedBox(height: 12),
                Row(
                  children: [
                    GestureDetector(
                      onTap: () => _toggleLike(post.id),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: isLiked ? Colors.red.withOpacity(0.1) : AppColors.bg,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: isLiked ? Colors.red.withOpacity(0.4) : AppColors.border),
                        ),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          Icon(isLiked ? Icons.favorite : Icons.favorite_border, size: 15, color: isLiked ? Colors.red : AppColors.textMuted),
                          const SizedBox(width: 6),
                          Text("$currentLikes j'aime",
                              style: AppTheme.sans(fontSize: 11, fontWeight: isLiked ? FontWeight.bold : FontWeight.normal, color: isLiked ? Colors.red.shade300 : AppColors.textMuted)),
                        ]),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(color: AppColors.bg, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.border)),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        const Icon(Icons.chat_bubble_outline, size: 14, color: AppColors.accent),
                        const SizedBox(width: 6),
                        Text('${post.commentsCount} commentaires', style: AppTheme.sans(fontSize: 11, color: AppColors.textMuted)),
                      ]),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _addModal() {
    return Positioned.fill(
      child: Container(
        color: Colors.black.withOpacity(0.8),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: Container(
              margin: const EdgeInsets.all(20),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(24), border: Border.all(color: AppColors.border)),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(child: Text('Créer une Nouvelle Entrée de Voyage', style: AppTheme.serif(fontSize: 16))),
                        IconButton(
                          onPressed: () => setState(() => isAddModalOpen = false),
                          icon: const Icon(Icons.close, size: 18, color: AppColors.textMuted),
                          style: IconButton.styleFrom(backgroundColor: AppColors.surfaceAlt),
                        ),
                      ],
                    ),
                    const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Divider(color: AppColors.border, height: 1)),
                    _field('Titre du Récit', _titleCtrl, hint: 'Ex: Coucher de soleil sur les Chutes de la Lobé'),
                    const SizedBox(height: 12),
                    _field('Lieu (Ville / Région)', _locationCtrl, hint: 'Ex: Kribi, Région du Sud'),
                    const SizedBox(height: 12),
                    _field('Image de Couverture (URL optionnelle)', _coverCtrl, hint: 'https://images.unsplash.com/...'),
                    const SizedBox(height: 12),
                    _field('Votre Récit / Impressions', _contentCtrl, hint: 'Racontez votre expérience...', maxLines: 4),
                    const SizedBox(height: 18),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: _createPost,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.accent,
                          foregroundColor: AppColors.bg,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        ),
                        icon: const Icon(Icons.send, size: 16),
                        label: Text("PUBLIER L'ENTRÉE", style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.bg)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _field(String label, TextEditingController ctrl, {String? hint, int maxLines = 1}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: AppTheme.sans(fontSize: 11, color: AppColors.textMuted)),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(color: AppColors.bg, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
          child: TextField(
            controller: ctrl,
            maxLines: maxLines,
            style: AppTheme.sans(fontSize: 12, color: Colors.white),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: AppTheme.sans(fontSize: 11.5, color: AppColors.textMuted),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            ),
          ),
        ),
      ],
    );
  }
}
