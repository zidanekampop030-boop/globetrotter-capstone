import 'package:flutter/material.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import '../utils/formatters.dart';
import '../widgets/hq_network_image.dart';

class ProfileScreen extends StatelessWidget {
  final UserProfile user;
  final int wishlistCount;
  final ValueChanged<String> onNavigateTab;
  final VoidCallback onLogout;

  const ProfileScreen({
    super.key,
    required this.user,
    required this.wishlistCount,
    required this.onNavigateTab,
    required this.onLogout,
  });

  static const _bookingHistory = [
    (id: 'res-1', title: 'Les Gîtes de Kribi • Ocean Lodge', date: '12-15 Mars 2026', amountXAF: 435000, status: 'Confirmé'),
    (id: 'res-2', title: 'Safari Parc National de Waza', date: '02-04 Février 2026', amountXAF: 180000, status: 'Terminé'),
  ];

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 760),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _profileHeader(context),
            const SizedBox(height: 20),
            _bookingsSection(),
            const SizedBox(height: 20),
            _accountControls(context),
          ],
        ),
      ),
    );
  }

  Widget _profileHeader(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(24), border: Border.all(color: AppColors.border)),
      child: Column(
        children: [
          Column(
            children: [
              Stack(
                clipBehavior: Clip.none,
                children: [
                  ClipOval(child: SizedBox(width: 100, height: 100, child: HqNetworkImage(url: user.avatarUrl, width: 400))),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: const BoxDecoration(color: AppColors.accent, shape: BoxShape.circle),
                      child: const Icon(Icons.camera_alt, size: 15, color: AppColors.bg),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Wrap(alignment: WrapAlignment.center, spacing: 8, runSpacing: 6, children: [
                Text(user.name, style: AppTheme.serif(fontSize: 20)),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                  decoration: BoxDecoration(
                    color: AppColors.accentDeep.withOpacity(0.4),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: AppColors.accent.withOpacity(0.4)),
                  ),
                  child: Text(user.statusTier, style: AppTheme.sans(fontSize: 10.5, fontWeight: FontWeight.bold, color: AppColors.accent)),
                ),
              ]),
              const SizedBox(height: 6),
              Text('${user.handle} • Yaoundé, Cameroun', style: AppTheme.sans(fontSize: 11.5, color: AppColors.textMuted)),
              const SizedBox(height: 10),
              Text(user.bio, textAlign: TextAlign.center, style: AppTheme.sans(fontSize: 11.5, color: AppColors.textPrimary, height: 1.4)),
              const SizedBox(height: 14),
              OutlinedButton.icon(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Lien de profil copié !')));
                },
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.accent,
                  side: const BorderSide(color: AppColors.border),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                icon: const Icon(Icons.share, size: 14),
                label: Text('Partager mon Profil', style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.accent)),
              ),
            ],
          ),
          const SizedBox(height: 20),
          const Divider(color: AppColors.border, height: 1),
          const SizedBox(height: 20),
          Row(children: [
            Expanded(child: _statBox('${user.countriesVisited}', 'Régions & Villes', AppColors.accent)),
            const SizedBox(width: 10),
            Expanded(child: _statBox(formatXAF(user.distanceKm), 'KM Parcourus', AppColors.gold)),
            const SizedBox(width: 10),
            Expanded(child: _statBox('${user.memoriesSaved}', 'Souvenirs', AppColors.accent)),
          ]),
        ],
      ),
    );
  }

  Widget _statBox(String value, String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(color: AppColors.bg, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.border)),
      child: Column(
        children: [
          Text(value, style: AppTheme.serif(fontSize: 18, color: color)),
          const SizedBox(height: 2),
          Text(label, textAlign: TextAlign.center, style: AppTheme.sans(fontSize: 9, color: AppColors.textMuted)),
        ],
      ),
    );
  }

  Widget _bookingsSection() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(24), border: Border.all(color: AppColors.border)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            const Icon(Icons.credit_card, size: 18, color: AppColors.accent),
            const SizedBox(width: 8),
            Expanded(child: Text('Mes Réservations & Transactions Mobile Money', style: AppTheme.serif(fontSize: 15))),
          ]),
          const SizedBox(height: 14),
          ..._bookingHistory.map((b) => Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: AppColors.bg, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.border)),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(b.title, style: AppTheme.sans(fontSize: 12.5, fontWeight: FontWeight.bold, color: Colors.white)),
                          const SizedBox(height: 2),
                          Text(b.date, style: AppTheme.sans(fontSize: 10.5, color: AppColors.textMuted)),
                        ],
                      ),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text('${formatXAF(b.amountXAF)} XAF', style: AppTheme.sans(fontSize: 12.5, fontWeight: FontWeight.bold, color: AppColors.accent)),
                        const SizedBox(height: 4),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(color: AppColors.accentDeep.withOpacity(0.3), borderRadius: BorderRadius.circular(8)),
                          child: Text(b.status, style: AppTheme.sans(fontSize: 9.5, fontWeight: FontWeight.w600, color: AppColors.accent)),
                        ),
                      ],
                    ),
                  ],
                ),
              )),
        ],
      ),
    );
  }

  Widget _accountControls(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: AppColors.border)),
      child: Column(
        children: [
          SizedBox(
            width: double.infinity,
            child: TextButton.icon(
              onPressed: () => onNavigateTab('wishlist'),
              icon: const Icon(Icons.favorite, size: 15, color: AppColors.accent),
              label: Text('Voir ma Liste de Souhaits ($wishlistCount)', style: AppTheme.sans(fontSize: 12, fontWeight: FontWeight.bold, color: AppColors.accent)),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: onLogout,
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.red.shade300,
                backgroundColor: Colors.red.withOpacity(0.1),
                side: BorderSide(color: Colors.red.withOpacity(0.3)),
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              icon: const Icon(Icons.logout, size: 15),
              label: Text('Se Déconnecter', style: AppTheme.sans(fontSize: 11.5, fontWeight: FontWeight.bold, color: Colors.red.shade300)),
            ),
          ),
        ],
      ),
    );
  }
}
