import 'package:flutter/material.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import '../widgets/hq_network_image.dart';

class RegionsScreen extends StatefulWidget {
  final List<RegionInfo> regions;
  final ValueChanged<String> onSelectRegionExplore;

  const RegionsScreen({super.key, required this.regions, required this.onSelectRegionExplore});

  @override
  State<RegionsScreen> createState() => _RegionsScreenState();
}

class _RegionsScreenState extends State<RegionsScreen> {
  String searchQuery = '';
  RegionInfo? selectedRegionModal;
  final TextEditingController _newsletterController = TextEditingController();
  bool subscribed = false;

  List<RegionInfo> get filteredRegions {
    final q = searchQuery.toLowerCase();
    return widget.regions
        .where((r) =>
            r.name.toLowerCase().contains(q) ||
            r.capital.toLowerCase().contains(q) ||
            r.description.toLowerCase().contains(q))
        .toList();
  }

  RegionInfo get centreRegion =>
      widget.regions.firstWhere((r) => r.name == 'Centre', orElse: () => widget.regions.first);

  void _subscribe() {
    if (_newsletterController.text.isNotEmpty) {
      setState(() => subscribed = true);
      Future.delayed(const Duration(seconds: 4), () {
        if (mounted) setState(() => subscribed = false);
      });
      _newsletterController.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final crossAxisCount = width >= 1100 ? 3 : (width >= 700 ? 2 : 1);

    return Stack(
      children: [
        SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _searchHeader(),
              const SizedBox(height: 24),
              if (searchQuery.isEmpty) _spotlightCard(),
              if (searchQuery.isEmpty) const SizedBox(height: 24),
              Text('Toutes les Régions (${filteredRegions.length})', style: AppTheme.serif(fontSize: 17)),
              const SizedBox(height: 14),
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: filteredRegions.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: crossAxisCount,
                  mainAxisSpacing: 20,
                  crossAxisSpacing: 20,
                  childAspectRatio: 0.78,
                ),
                itemBuilder: (context, i) => _regionCard(filteredRegions[i]),
              ),
              const SizedBox(height: 24),
              _newsletterBanner(),
            ],
          ),
        ),
        if (selectedRegionModal != null) _regionModal(selectedRegionModal!),
      ],
    );
  }

  Widget _searchHeader() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(22), border: Border.all(color: AppColors.border)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("L'AFRIQUE EN MINIATURE", style: AppTheme.sans(fontSize: 10, fontWeight: FontWeight.bold, color: AppColors.accent)),
          const SizedBox(height: 6),
          Text('Les 10 Régions du Cameroun', style: AppTheme.serif(fontSize: 20)),
          const SizedBox(height: 14),
          Container(
            decoration: BoxDecoration(color: AppColors.bg, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
            child: TextField(
              style: AppTheme.sans(fontSize: 12, color: Colors.white),
              onChanged: (v) => setState(() => searchQuery = v),
              decoration: InputDecoration(
                hintText: 'Rechercher une région ou ville...',
                hintStyle: AppTheme.sans(fontSize: 12, color: AppColors.textMuted),
                prefixIcon: const Icon(Icons.search, size: 18, color: AppColors.textMuted),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(vertical: 12),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _spotlightCard() {
    final r = centreRegion;
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: Container(
        decoration: BoxDecoration(border: Border.all(color: AppColors.accent.withOpacity(0.4)), borderRadius: BorderRadius.circular(24)),
        child: Stack(
          children: [
            SizedBox(height: 320, width: double.infinity, child: HqNetworkImage(url: r.imageUrl)),
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                    colors: [AppColors.bg.withOpacity(0.95), AppColors.bg.withOpacity(0.55), Colors.transparent],
                  ),
                ),
              ),
            ),
            Positioned(
              left: 20,
              right: 20,
              bottom: 20,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: AppColors.accentDeep.withOpacity(0.4),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: AppColors.accent.withOpacity(0.4)),
                    ),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.auto_awesome, size: 13, color: AppColors.gold),
                      const SizedBox(width: 6),
                      Text("RÉGION À L'HONNEUR", style: AppTheme.sans(fontSize: 10, fontWeight: FontWeight.w700, color: AppColors.accent)),
                    ]),
                  ),
                  const SizedBox(height: 8),
                  Text('Région du ${r.name} (${r.capital})', style: AppTheme.serif(fontSize: 22)),
                  const SizedBox(height: 6),
                  Text('${r.motto}. ${r.description}',
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                      style: AppTheme.sans(fontSize: 11.5, color: AppColors.textPrimary.withOpacity(0.9), height: 1.4)),
                  const SizedBox(height: 14),
                  Wrap(spacing: 10, runSpacing: 10, children: [
                    ElevatedButton.icon(
                      onPressed: () => widget.onSelectRegionExplore(r.name),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.accent,
                        foregroundColor: AppColors.bg,
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      icon: const Icon(Icons.chevron_right, size: 16),
                      label: Text('Voir les Hébergements', style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.bg)),
                    ),
                    OutlinedButton(
                      onPressed: () => setState(() => selectedRegionModal = r),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.white,
                        side: const BorderSide(color: AppColors.border),
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      child: Text('En savoir plus', style: AppTheme.sans(fontSize: 11, color: Colors.white)),
                    ),
                  ]),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _regionCard(RegionInfo region) {
    return GestureDetector(
      onTap: () => setState(() => selectedRegionModal = region),
      child: Container(
        decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: AppColors.border)),
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AspectRatio(
              aspectRatio: 16 / 10,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  HqNetworkImage(url: region.imageUrl),
                  const DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.bottomCenter,
                        end: Alignment.topCenter,
                        colors: [AppColors.bg, Colors.transparent],
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 10,
                    left: 10,
                    child: Text('Région ${region.name}', style: AppTheme.serif(fontSize: 16)),
                  ),
                  Positioned(
                    top: 10,
                    right: 10,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: AppColors.bg.withOpacity(0.8),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: AppColors.accent.withOpacity(0.3)),
                      ),
                      child: Text('Cap: ${region.capital}', style: AppTheme.sans(fontSize: 9.5, fontWeight: FontWeight.bold, color: AppColors.accent)),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(region.description, maxLines: 2, overflow: TextOverflow.ellipsis, style: AppTheme.sans(fontSize: 11, color: AppColors.textMuted, height: 1.35)),
                        const SizedBox(height: 8),
                        Text('SITES INCONTOURNABLES', style: AppTheme.sans(fontSize: 9, fontWeight: FontWeight.bold, color: AppColors.gold)),
                        const SizedBox(height: 6),
                        Wrap(
                          spacing: 6,
                          runSpacing: 6,
                          children: region.highlights.take(3).map((h) {
                            return Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(color: AppColors.bg, borderRadius: BorderRadius.circular(8), border: Border.all(color: AppColors.border)),
                              child: Text(h, style: AppTheme.sans(fontSize: 9.5, color: Colors.white)),
                            );
                          }).toList(),
                        ),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Divider(color: AppColors.border, height: 1)),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('Découvrir la région', style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.accent)),
                            const Icon(Icons.chevron_right, size: 15, color: AppColors.accent),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _newsletterBanner() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(24), border: Border.all(color: AppColors.border)),
      child: Column(
        children: [
          Text('Préparez votre prochain voyage au Cameroun', textAlign: TextAlign.center, style: AppTheme.serif(fontSize: 17)),
          const SizedBox(height: 8),
          Text(
            "Recevez nos guides de voyage exclusifs, conseils de route et promotions sur les éco-lodges directement dans votre boîte mail.",
            textAlign: TextAlign.center,
            style: AppTheme.sans(fontSize: 11, color: AppColors.textMuted, height: 1.4),
          ),
          const SizedBox(height: 16),
          Row(children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(color: AppColors.bg, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
                child: TextField(
                  controller: _newsletterController,
                  style: AppTheme.sans(fontSize: 12, color: Colors.white),
                  decoration: InputDecoration(
                    hintText: 'Votre adresse email...',
                    hintStyle: AppTheme.sans(fontSize: 12, color: AppColors.textMuted),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            ElevatedButton.icon(
              onPressed: _subscribe,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.accent,
                foregroundColor: AppColors.bg,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              icon: const Icon(Icons.send, size: 14),
              label: Text("S'abonner", style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.bg)),
            ),
          ]),
          if (subscribed)
            Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                const Icon(Icons.check_circle, size: 15, color: AppColors.accent),
                const SizedBox(width: 6),
                Text('Merci ! Vous êtes bien inscrit à notre lettre.', style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.accent)),
              ]),
            ),
        ],
      ),
    );
  }

  Widget _regionModal(RegionInfo r) {
    return Positioned.fill(
      child: Container(
        color: Colors.black.withOpacity(0.8),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: Container(
              margin: const EdgeInsets.all(20),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(24), border: Border.all(color: AppColors.border)),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Région du ${r.name}', style: AppTheme.serif(fontSize: 18)),
                              Text('Chef-lieu: ${r.capital}', style: AppTheme.sans(fontSize: 11, color: AppColors.accent)),
                            ],
                          ),
                        ),
                        IconButton(
                          onPressed: () => setState(() => selectedRegionModal = null),
                          icon: const Icon(Icons.close, size: 18, color: AppColors.textMuted),
                          style: IconButton.styleFrom(backgroundColor: AppColors.surfaceAlt),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: AspectRatio(aspectRatio: 16 / 9, child: HqNetworkImage(url: r.imageUrl)),
                    ),
                    const SizedBox(height: 14),
                    Text(r.description, style: AppTheme.sans(fontSize: 12, color: AppColors.textMuted, height: 1.5)),
                    const SizedBox(height: 14),
                    Row(children: [
                      const Icon(Icons.thermostat, size: 16, color: AppColors.gold),
                      const SizedBox(width: 8),
                      Expanded(child: Text('Climat: ${r.climate}', style: AppTheme.sans(fontSize: 11.5, color: Colors.white))),
                    ]),
                    const SizedBox(height: 8),
                    Row(children: [
                      const Icon(Icons.restaurant, size: 16, color: AppColors.accent),
                      const SizedBox(width: 8),
                      Expanded(child: Text('Spécialité: ${r.famousDish}', style: AppTheme.sans(fontSize: 11.5, color: Colors.white))),
                    ]),
                    const SizedBox(height: 18),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {
                          widget.onSelectRegionExplore(r.name);
                          setState(() => selectedRegionModal = null);
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.accent,
                          foregroundColor: AppColors.bg,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        ),
                        child: Text('VOIR LES LOGEMENTS DU ${r.name.toUpperCase()}',
                            style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.bg)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
