import 'package:flutter/material.dart';
import '../data/mock_data.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import '../utils/formatters.dart';

class TransitScreen extends StatefulWidget {
  const TransitScreen({super.key});

  @override
  State<TransitScreen> createState() => _TransitScreenState();
}

class _TransitScreenState extends State<TransitScreen> {
  String origin = 'Yaoundé Mvan';
  String destination = 'Douala Akwa';
  TransitMode mode = TransitMode.bus;
  bool isCalculating = false;

  late TransitRoute result = const TransitRoute(
    origin: 'Yaoundé Mvan',
    destination: 'Douala Akwa',
    mode: TransitMode.bus,
    minFareXAF: 3500,
    maxFareXAF: 5000,
    estimatedMinutes: 210,
    tips:
        'Trajet interurbain recommandé via les agences VIP de Mvan. Départs réguliers toutes les 30 minutes.',
  );

  void _swap() {
    setState(() {
      final t = origin;
      origin = destination;
      destination = t;
    });
  }

  Future<void> _calculate() async {
    setState(() => isCalculating = true);
    // Simule un calcul local (équivalent du fallback client de l'API Express)
    await Future.delayed(const Duration(milliseconds: 500));
    final baseByMode = {
      TransitMode.bus: (min: 3500, max: 5000, mins: 210, tips: 'Trajet interurbain recommandé via les agences VIP. Départs réguliers toutes les 30 minutes.'),
      TransitMode.taxi: (min: 15000, max: 25000, mins: 195, tips: 'VTC ou taxi privatisé, plus rapide mais tarif négocié à l\'avance recommandé.'),
      TransitMode.moto: (min: 1000, max: 2500, mins: 15, tips: 'Idéal pour de courtes distances urbaines. Négociez le tarif avant le départ.'),
      TransitMode.train: (min: 4000, max: 9000, mins: 480, tips: 'Camrail: trajet confortable de nuit, réservez une couchette à l\'avance.'),
    }[mode]!;

    setState(() {
      result = TransitRoute(
        origin: origin,
        destination: destination,
        mode: mode,
        minFareXAF: baseByMode.min,
        maxFareXAF: baseByMode.max,
        estimatedMinutes: baseByMode.mins,
        tips: baseByMode.tips,
      );
      isCalculating = false;
    });
  }

  void _alert(String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        content: Text(msg, style: AppTheme.sans(fontSize: 12, color: Colors.white)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.of(context).size.width >= 900;

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _header(),
          const SizedBox(height: 24),
          isWide
              ? IntrinsicHeight(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(flex: 7, child: _formPanel()),
                      const SizedBox(width: 20),
                      Expanded(flex: 5, child: _resultPanel()),
                    ],
                  ),
                )
              : Column(children: [_formPanel(), const SizedBox(height: 20), _resultPanel()]),
        ],
      ),
    );
  }

  Widget _header() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            const Icon(Icons.directions_bus, size: 15, color: AppColors.accent),
            const SizedBox(width: 6),
            Text('TRANSIT CAMEROUN • ESTIMATION DES FRAIS',
                style: AppTheme.sans(fontSize: 10, fontWeight: FontWeight.bold, color: AppColors.accent)),
          ]),
          const SizedBox(height: 8),
          Text('Calculateur de Dépenses & Transports Interurbains', style: AppTheme.serif(fontSize: 20)),
          const SizedBox(height: 8),
          Text(
            "Estimez les tarifs officiels et recommandés pour vos déplacements en taxi ville, moto-taxi, car interurbain VIP ou train Camrail à travers tout le Cameroun.",
            style: AppTheme.sans(fontSize: 12, color: AppColors.textMuted, height: 1.4),
          ),
        ],
      ),
    );
  }

  Widget _modeButton(TransitMode m, String label, IconData icon) {
    final isSelected = mode == m;
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 3),
        child: Material(
          color: isSelected ? AppColors.accent : AppColors.bg,
          borderRadius: BorderRadius.circular(16),
          child: InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: () => setState(() => mode = m),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: isSelected ? AppColors.accent : AppColors.border),
              ),
              child: Column(children: [
                Icon(icon, size: 18, color: isSelected ? AppColors.bg : AppColors.textMuted),
                const SizedBox(height: 4),
                Text(label,
                    style: AppTheme.sans(
                        fontSize: 9.5,
                        fontWeight: FontWeight.w700,
                        color: isSelected ? AppColors.bg : AppColors.textMuted)),
              ]),
            ),
          ),
        ),
      ),
    );
  }

  Widget _citySelect({required String label, required IconData icon, required Color iconColor, required String value, required ValueChanged<String?> onChanged}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          Icon(icon, size: 13, color: iconColor),
          const SizedBox(width: 6),
          Text(label, style: AppTheme.sans(fontSize: 11, color: AppColors.textMuted)),
        ]),
        const SizedBox(height: 6),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            color: AppColors.bg,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: value,
              isExpanded: true,
              dropdownColor: AppColors.surface,
              style: AppTheme.sans(fontSize: 12, color: Colors.white),
              icon: const Icon(Icons.keyboard_arrow_down, color: AppColors.textMuted),
              items: transitCityOptions
                  .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                  .toList(),
              onChanged: onChanged,
            ),
          ),
        ),
      ],
    );
  }

  Widget _formPanel() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            const Icon(Icons.calculate_outlined, size: 18, color: AppColors.accent),
            const SizedBox(width: 8),
            Text('Paramètres de Votre Trajet', style: AppTheme.serif(fontSize: 16)),
          ]),
          const SizedBox(height: 16),
          Text('Mode de Transport', style: AppTheme.sans(fontSize: 11, color: AppColors.textMuted)),
          const SizedBox(height: 8),
          Row(children: [
            _modeButton(TransitMode.bus, 'BUS VIP', Icons.directions_bus),
            _modeButton(TransitMode.taxi, 'TAXI VTC', Icons.local_taxi),
            _modeButton(TransitMode.moto, 'MOTO', Icons.moped),
            _modeButton(TransitMode.train, 'TRAIN', Icons.train),
          ]),
          const SizedBox(height: 20),
          _citySelect(
            label: 'Lieu de Départ (Origin)',
            icon: Icons.location_on,
            iconColor: AppColors.accent,
            value: origin,
            onChanged: (v) => setState(() => origin = v!),
          ),
          Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Material(
                color: AppColors.surfaceAlt,
                shape: const CircleBorder(),
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: _swap,
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: Icon(Icons.swap_vert, size: 18, color: AppColors.accent),
                  ),
                ),
              ),
            ),
          ),
          _citySelect(
            label: "Lieu d'Arrivée (Destination)",
            icon: Icons.navigation_outlined,
            iconColor: AppColors.gold,
            value: destination,
            onChanged: (v) => setState(() => destination = v!),
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: isCalculating ? null : _calculate,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.accent,
                foregroundColor: AppColors.bg,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
              ),
              icon: isCalculating
                  ? const SizedBox(
                      width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.bg))
                  : const Icon(Icons.calculate, size: 16),
              label: Text(isCalculating ? 'Calcul en cours...' : "CALCULER L'ESTIMATION",
                  style: AppTheme.sans(fontSize: 12, fontWeight: FontWeight.bold, color: AppColors.bg)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _resultPanel() {
    final hours = result.estimatedMinutes ~/ 60;
    final mins = result.estimatedMinutes % 60;
    final durationLabel = hours > 0 ? '${hours}h ${mins}m' : '${result.estimatedMinutes} mins';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: AppColors.accent.withOpacity(0.4)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('RÉSULTAT DU CALCUL', style: AppTheme.sans(fontSize: 10, fontWeight: FontWeight.bold, color: AppColors.textMuted)),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.accentDeep.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text('Mode: ${result.mode.label}',
                        style: AppTheme.sans(fontSize: 10, fontWeight: FontWeight.w600, color: AppColors.accent)),
                  ),
                ],
              ),
              const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Divider(color: AppColors.border, height: 1)),
              Text('Fourchette de prix estimée:', style: AppTheme.sans(fontSize: 11, color: AppColors.textMuted)),
              const SizedBox(height: 4),
              Text.rich(
                TextSpan(children: [
                  TextSpan(
                      text: '${formatXAF(result.minFareXAF)} – ${formatXAF(result.maxFareXAF)} ',
                      style: AppTheme.serif(fontSize: 26, color: AppColors.accent)),
                  TextSpan(text: 'XAF', style: AppTheme.sans(fontSize: 13, color: AppColors.textMuted)),
                ]),
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.bg,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.border),
                ),
                child: Row(children: [
                  const Icon(Icons.access_time, size: 18, color: AppColors.gold),
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Temps de trajet estimé:', style: AppTheme.sans(fontSize: 9, color: AppColors.textMuted)),
                      Text('~ $durationLabel', style: AppTheme.sans(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.white)),
                    ],
                  ),
                ]),
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.surfaceAlt,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.borderLight),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(Icons.info_outline, size: 16, color: AppColors.accent),
                    const SizedBox(width: 10),
                    Expanded(child: Text(result.tips, style: AppTheme.sans(fontSize: 11, color: AppColors.textMuted, height: 1.4))),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () => _alert('Réservation de VTC initiée pour le trajet $origin -> $destination'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.gold,
                    foregroundColor: AppColors.bg,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  icon: const Icon(Icons.directions_car, size: 16),
                  label: Text('COMMANDER UN VTC (YANGO / SAWA)',
                      style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.bg)),
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () => _alert('Station de départ recommandée: Gare Routière de $origin'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.textPrimary,
                    side: const BorderSide(color: AppColors.border),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  icon: const Icon(Icons.location_on, size: 15, color: AppColors.accent),
                  label: Text('Localiser la Gare Routière', style: AppTheme.sans(fontSize: 11, color: Colors.white)),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: AppColors.border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                const Icon(Icons.check_circle_outline, size: 16, color: AppColors.accent),
                const SizedBox(width: 8),
                Text('Conseils de Voyage au Cameroun', style: AppTheme.serif(fontSize: 14)),
              ]),
              const SizedBox(height: 10),
              _tipItem(
                  "Taxi Ville (Ramassage): Le tarif urbain jour à Yaoundé et Douala est de 250 à 300 XAF. Le dépôt (course privatisée) varie entre 1 500 et 2 500 XAF."),
              const SizedBox(height: 8),
              _tipItem(
                  "Voyage Interurbain VIP: Privilégiez les agences réputées (Finexs, Buca, Touristique Express) avec climatisation et réservation à l'avance."),
            ],
          ),
        ),
      ],
    );
  }

  Widget _tipItem(String text) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          margin: const EdgeInsets.only(top: 5, right: 8),
          width: 5,
          height: 5,
          decoration: const BoxDecoration(color: AppColors.accent, shape: BoxShape.circle),
        ),
        Expanded(child: Text(text, style: AppTheme.sans(fontSize: 11, color: AppColors.textMuted, height: 1.4))),
      ],
    );
  }
}
