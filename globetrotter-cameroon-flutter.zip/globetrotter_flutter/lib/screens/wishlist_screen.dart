import 'package:flutter/material.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import '../widgets/hq_network_image.dart';

class WishlistScreen extends StatefulWidget {
  final List<WishlistItem> items;
  final ValueChanged<String> onRemoveItem;
  final ValueChanged<String> onExploreLocation;

  const WishlistScreen({super.key, required this.items, required this.onRemoveItem, required this.onExploreLocation});

  @override
  State<WishlistScreen> createState() => _WishlistScreenState();
}

class _WishlistScreenState extends State<WishlistScreen> {
  bool isItineraryModalOpen = false;

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final crossAxisCount = width >= 1100 ? 3 : (width >= 700 ? 2 : 1);

    return Stack(
      children: [
        SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _header(),
              const SizedBox(height: 20),
              if (widget.items.isEmpty)
                _emptyState()
              else
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: widget.items.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: crossAxisCount,
                    mainAxisSpacing: 20,
                    crossAxisSpacing: 20,
                    childAspectRatio: 0.85,
                  ),
                  itemBuilder: (context, i) => _wishCard(widget.items[i]),
                ),
            ],
          ),
        ),
        if (isItineraryModalOpen) _itineraryModal(),
      ],
    );
  }

  Widget _header() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(22), border: Border.all(color: AppColors.border)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            const Icon(Icons.favorite, size: 15, color: AppColors.accent),
            const SizedBox(width: 6),
            Expanded(
              child: Text('HERITAGE & HORIZONS • MES SOUHAITS',
                  style: AppTheme.sans(fontSize: 10, fontWeight: FontWeight.bold, color: AppColors.accent)),
            ),
          ]),
          const SizedBox(height: 8),
          Text('Ma Liste de Souhaits (${widget.items.length})', style: AppTheme.serif(fontSize: 19)),
          const SizedBox(height: 6),
          Text("Vos destinations, monuments et lieux d'exception sauvegardés pour votre prochain voyage.",
              style: AppTheme.sans(fontSize: 11.5, color: AppColors.textMuted, height: 1.4)),
          if (widget.items.isNotEmpty) ...[
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () => setState(() => isItineraryModalOpen = true),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.gold,
                  foregroundColor: AppColors.bg,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                icon: const Icon(Icons.map_outlined, size: 16),
                label: Text('PLANIFIER UN ITINÉRAIRE', style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.bg)),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _emptyState() {
    return Container(
      padding: const EdgeInsets.all(40),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(24), border: Border.all(color: AppColors.border)),
      child: Column(
        children: [
          Icon(Icons.favorite_border, size: 44, color: AppColors.textMuted.withOpacity(0.4)),
          const SizedBox(height: 12),
          Text('Votre liste de souhaits est vide', style: AppTheme.serif(fontSize: 16)),
          const SizedBox(height: 8),
          Text(
            'Parcourez nos destinations exclusives et cliquez sur le cœur pour sauvegarder vos favoris.',
            textAlign: TextAlign.center,
            style: AppTheme.sans(fontSize: 11.5, color: AppColors.textMuted, height: 1.4),
          ),
        ],
      ),
    );
  }

  Widget _wishCard(WishlistItem item) {
    return Container(
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: AppColors.border)),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          AspectRatio(
            aspectRatio: 16 / 10,
            child: Stack(
              fit: StackFit.expand,
              children: [
                HqNetworkImage(url: item.imageUrl),
                Positioned(
                  top: 10,
                  left: 10,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.bg.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: AppColors.accent.withOpacity(0.3)),
                    ),
                    child: Text(item.type.label, style: AppTheme.sans(fontSize: 9.5, fontWeight: FontWeight.bold, color: AppColors.accent)),
                  ),
                ),
                Positioned(
                  top: 10,
                  right: 10,
                  child: GestureDetector(
                    onTap: () => widget.onRemoveItem(item.id),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(color: Colors.red.withOpacity(0.85), shape: BoxShape.circle),
                      child: const Icon(Icons.delete_outline, size: 15, color: Colors.white),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(children: [
                        const Icon(Icons.location_on, size: 12, color: AppColors.accent),
                        const SizedBox(width: 4),
                        Expanded(child: Text(item.location, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTheme.sans(fontSize: 11, color: AppColors.accent))),
                      ]),
                      const SizedBox(height: 6),
                      Text(item.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: AppTheme.serif(fontSize: 14.5, height: 1.2)),
                      const SizedBox(height: 4),
                      Text('Ajouté: ${item.addedAt}', style: AppTheme.sans(fontSize: 10, color: AppColors.textMuted)),
                    ],
                  ),
                  InkWell(
                    onTap: () => widget.onExploreLocation(item.location),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Text('Explorer le secteur', style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.gold)),
                      const SizedBox(width: 4),
                      const Icon(Icons.arrow_forward, size: 13, color: AppColors.gold),
                    ]),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _itineraryModal() {
    return Positioned.fill(
      child: Container(
        color: Colors.black.withOpacity(0.8),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: Container(
              margin: const EdgeInsets.all(20),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(24), border: Border.all(color: AppColors.border)),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(children: [
                          const Icon(Icons.explore, size: 18, color: AppColors.accent),
                          const SizedBox(width: 8),
                          Text('Itinéraire Optimisé', style: AppTheme.serif(fontSize: 16)),
                        ]),
                        IconButton(
                          onPressed: () => setState(() => isItineraryModalOpen = false),
                          icon: const Icon(Icons.close, size: 18, color: AppColors.textMuted),
                          style: IconButton.styleFrom(backgroundColor: AppColors.surfaceAlt),
                        ),
                      ],
                    ),
                    const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Divider(color: AppColors.border, height: 1)),
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(color: AppColors.bg, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.border)),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('Distance Totale: ~620 KM', style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.accent)),
                              Text('Durée: 5 à 7 Jours', style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.accent)),
                            ],
                          ),
                          const SizedBox(height: 10),
                          ...widget.items.asMap().entries.map((e) {
                            final idx = e.key;
                            final it = e.value;
                            return Padding(
                              padding: const EdgeInsets.only(bottom: 8),
                              child: Container(
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
                                child: Row(children: [
                                  Container(
                                    width: 24,
                                    height: 24,
                                    alignment: Alignment.center,
                                    decoration: const BoxDecoration(color: AppColors.accent, shape: BoxShape.circle),
                                    child: Text('${idx + 1}', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.bg)),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(it.title, style: AppTheme.sans(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.white)),
                                        Text(it.location, style: AppTheme.sans(fontSize: 10.5, color: AppColors.textMuted)),
                                      ],
                                    ),
                                  ),
                                ]),
                              ),
                            );
                          }),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: () {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Itinéraire exporté avec succès dans votre profil !')),
                          );
                          setState(() => isItineraryModalOpen = false);
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.accent,
                          foregroundColor: AppColors.bg,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        ),
                        icon: const Icon(Icons.check_circle, size: 16),
                        label: Text('ENREGISTRER CET ITINÉRAIRE', style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.bg)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
