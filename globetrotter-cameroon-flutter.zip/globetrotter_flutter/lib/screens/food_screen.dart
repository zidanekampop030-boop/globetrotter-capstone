import 'package:flutter/material.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import '../utils/formatters.dart';
import '../widgets/hq_network_image.dart';

class FoodScreen extends StatefulWidget {
  final List<Dish> dishes;
  final ValueChanged<PayableItem> onOrderDish;

  const FoodScreen({super.key, required this.dishes, required this.onOrderDish});

  @override
  State<FoodScreen> createState() => _FoodScreenState();
}

class _FoodScreenState extends State<FoodScreen> {
  String selectedCategory = 'Tous';
  Dish? activeDishModal;

  List<Dish> get filteredDishes {
    if (selectedCategory == 'Tous') return widget.dishes;
    return widget.dishes.where((d) => d.category.label == selectedCategory).toList();
  }

  void _openDishModal(Dish d) => setState(() => activeDishModal = d);
  void _closeDishModal() => setState(() => activeDishModal = null);

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final crossAxisCount = width >= 1100 ? 3 : (width >= 700 ? 2 : 1);

    return Stack(
      children: [
        SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _heroBanner(),
              const SizedBox(height: 24),
              _categoryTabs(),
              const SizedBox(height: 20),
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: filteredDishes.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: crossAxisCount,
                  mainAxisSpacing: 20,
                  crossAxisSpacing: 20,
                  childAspectRatio: 0.72,
                ),
                itemBuilder: (context, i) => _dishCard(filteredDishes[i]),
              ),
            ],
          ),
        ),
        if (activeDishModal != null) _dishModal(activeDishModal!),
      ],
    );
  }

  Widget _heroBanner() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: Container(
        decoration: BoxDecoration(border: Border.all(color: AppColors.border), borderRadius: BorderRadius.circular(24)),
        child: Stack(
          children: [
            SizedBox(
              height: 300,
              width: double.infinity,
              child: HqNetworkImage(
                url: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=1600&q=85',
                width: 1600,
              ),
            ),
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                    colors: [AppColors.bg.withOpacity(0.95), AppColors.bg.withOpacity(0.6), Colors.transparent],
                  ),
                ),
              ),
            ),
            Positioned(
              left: 20,
              right: 20,
              bottom: 20,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: AppColors.gold.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: AppColors.gold.withOpacity(0.4)),
                    ),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.ramen_dining, size: 13, color: AppColors.gold),
                      const SizedBox(width: 6),
                      Text('GASTRONOMIE ANCESTRALE & MODERNE',
                          style: AppTheme.sans(fontSize: 10, fontWeight: FontWeight.w700, color: AppColors.gold)),
                    ]),
                  ),
                  const SizedBox(height: 8),
                  Text('Heritage Cuisine • Cuisine Patrimoniale', style: AppTheme.serif(fontSize: 22)),
                  const SizedBox(height: 8),
                  Text(
                    "Découvrez l'âme du Cameroun à travers nos spécialités régionales mijotées avec les épices rares du terroir comme le Poivre Blanc de Penja et le Djansang.",
                    style: AppTheme.sans(fontSize: 11.5, color: AppColors.textPrimary.withOpacity(0.9), height: 1.4),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _categoryTabs() {
    const cats = ['Tous', 'Traditionnel', 'Moderne / Fusion'];
    return Container(
      padding: const EdgeInsets.only(bottom: 14),
      decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: AppColors.border))),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: cats.map((cat) {
            final isSelected = selectedCategory == cat;
            return Padding(
              padding: const EdgeInsets.only(right: 8),
              child: ChoiceChip(
                label: Text(cat == 'Tous' ? 'Tous les Plats' : cat),
                selected: isSelected,
                onSelected: (_) => setState(() => selectedCategory = cat),
                labelStyle: AppTheme.sans(
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  color: isSelected ? AppColors.bg : AppColors.textMuted,
                ),
                backgroundColor: AppColors.surface,
                selectedColor: AppColors.accent,
                side: BorderSide(color: isSelected ? Colors.transparent : AppColors.border),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  Widget _dishCard(Dish dish) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.border),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          AspectRatio(
            aspectRatio: 4 / 3,
            child: Stack(
              fit: StackFit.expand,
              children: [
                HqNetworkImage(url: dish.imageUrl),
                Positioned(
                  top: 10,
                  left: 10,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.bg.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: AppColors.gold.withOpacity(0.3)),
                    ),
                    child: Text(dish.region, style: AppTheme.sans(fontSize: 9.5, fontWeight: FontWeight.bold, color: AppColors.gold)),
                  ),
                ),
                Positioned(
                  bottom: 10,
                  right: 10,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.bg.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.star, size: 12, color: AppColors.gold),
                      const SizedBox(width: 4),
                      Text('${dish.rating}', style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.white)),
                    ]),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(children: [
                            const Icon(Icons.access_time, size: 12, color: AppColors.accent),
                            const SizedBox(width: 4),
                            Text('${dish.prepTimeMinutes} mins', style: AppTheme.sans(fontSize: 10.5, color: AppColors.textMuted)),
                          ]),
                          Text(dish.category.label, style: AppTheme.sans(fontSize: 10.5, color: AppColors.accent)),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(dish.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: AppTheme.serif(fontSize: 15, height: 1.2)),
                      const SizedBox(height: 6),
                      Text(dish.description, maxLines: 2, overflow: TextOverflow.ellipsis, style: AppTheme.sans(fontSize: 11, color: AppColors.textMuted, height: 1.35)),
                      const SizedBox(height: 6),
                      InkWell(
                        onTap: () => _openDishModal(dish),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          const Icon(Icons.remove_red_eye_outlined, size: 13, color: AppColors.gold),
                          const SizedBox(width: 4),
                          Text('Voir la recette', style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.gold, height: 1)),
                        ]),
                      ),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 8),
                      const Divider(color: AppColors.border, height: 1),
                      const SizedBox(height: 10),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('PRIX PORTION', style: AppTheme.sans(fontSize: 9, color: AppColors.textMuted)),
                              Text('${formatXAF(dish.priceXAF)} XAF', style: AppTheme.sans(fontSize: 14, fontWeight: FontWeight.bold, color: AppColors.accent)),
                            ],
                          ),
                          ElevatedButton.icon(
                            onPressed: () => widget.onOrderDish(PayableItem(title: dish.title, priceXAF: dish.priceXAF, imageUrl: dish.imageUrl)),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.accent,
                              foregroundColor: AppColors.bg,
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            ),
                            icon: const Icon(Icons.shopping_bag_outlined, size: 13),
                            label: Text('Commander', style: AppTheme.sans(fontSize: 10.5, fontWeight: FontWeight.bold, color: AppColors.bg)),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _dishModal(Dish dish) {
    return Positioned.fill(
      child: Container(
        color: Colors.black.withOpacity(0.8),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: Container(
              margin: const EdgeInsets.all(20),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: AppColors.border),
              ),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(child: Text(dish.title, style: AppTheme.serif(fontSize: 16))),
                        IconButton(
                          onPressed: _closeDishModal,
                          icon: const Icon(Icons.close, size: 18, color: AppColors.textMuted),
                          style: IconButton.styleFrom(backgroundColor: AppColors.surfaceAlt),
                        ),
                      ],
                    ),
                    const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Divider(color: AppColors.border, height: 1)),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: AspectRatio(aspectRatio: 16 / 9, child: HqNetworkImage(url: dish.imageUrl)),
                    ),
                    const SizedBox(height: 14),
                    Text(dish.description, style: AppTheme.sans(fontSize: 12, color: AppColors.textMuted, height: 1.5)),
                    const SizedBox(height: 14),
                    Text('INGRÉDIENTS TRADITIONNELS', style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.white)),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: dish.ingredients.map((ing) {
                        return Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                          decoration: BoxDecoration(
                            color: AppColors.bg,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: AppColors.border),
                          ),
                          child: Row(mainAxisSize: MainAxisSize.min, children: [
                            const Icon(Icons.check, size: 13, color: AppColors.accent),
                            const SizedBox(width: 6),
                            Text(ing, style: AppTheme.sans(fontSize: 11, color: Colors.white)),
                          ]),
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 18),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: () {
                          widget.onOrderDish(PayableItem(title: dish.title, priceXAF: dish.priceXAF, imageUrl: dish.imageUrl));
                          _closeDishModal();
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.accent,
                          foregroundColor: AppColors.bg,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        ),
                        icon: const Icon(Icons.shopping_bag, size: 16),
                        label: Text('COMMANDER MA PORTION (${formatXAF(dish.priceXAF)} XAF)',
                            style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.bg)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
