import 'package:flutter/material.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';

class SafetyScreen extends StatefulWidget {
  final List<EmergencyContact> contacts;
  final List<HealthCenter> healthCenters;
  final List<SafetyAlert> alerts;

  const SafetyScreen({super.key, required this.contacts, required this.healthCenters, required this.alerts});

  @override
  State<SafetyScreen> createState() => _SafetyScreenState();
}

class _SafetyScreenState extends State<SafetyScreen> {
  EmergencyContact? activeCall;
  bool sosActive = false;

  IconData _iconFor(EmergencyType t) {
    switch (t) {
      case EmergencyType.police:
        return Icons.shield_outlined;
      case EmergencyType.pompiers:
        return Icons.local_fire_department_outlined;
      case EmergencyType.samu:
        return Icons.local_hospital_outlined;
      case EmergencyType.dispatch:
        return Icons.radio_outlined;
    }
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final contactCols = width >= 1000 ? 4 : (width >= 640 ? 2 : 1);
    final hcCols = width >= 900 ? 3 : 1;

    return Stack(
      children: [
        SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _header(),
              const SizedBox(height: 20),
              _alertsSection(),
              const SizedBox(height: 24),
              Text("Numéros d'Urgence Nationaux (24/7)", style: AppTheme.serif(fontSize: 16)),
              const SizedBox(height: 12),
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: widget.contacts.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: contactCols,
                  mainAxisSpacing: 14,
                  crossAxisSpacing: 14,
                  childAspectRatio: 1.05,
                ),
                itemBuilder: (context, i) => _contactCard(widget.contacts[i]),
              ),
              const SizedBox(height: 24),
              Row(children: [
                const Icon(Icons.local_hospital, size: 17, color: AppColors.accent),
                const SizedBox(width: 8),
                Text('Centres de Santé Proches (Yaoundé)', style: AppTheme.serif(fontSize: 16)),
              ]),
              const SizedBox(height: 12),
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: widget.healthCenters.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: hcCols,
                  mainAxisSpacing: 14,
                  crossAxisSpacing: 14,
                  childAspectRatio: 1.7,
                ),
                itemBuilder: (context, i) => _healthCard(widget.healthCenters[i]),
              ),
            ],
          ),
        ),
        if (activeCall != null) _callModal(activeCall!),
        if (sosActive) _sosModal(),
      ],
    );
  }

  Widget _header() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(22), border: Border.all(color: Colors.red.withOpacity(0.3))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Icon(Icons.shield, size: 15, color: Colors.red.shade300),
            const SizedBox(width: 6),
            Text('ASSISTANCE & SÉCURITÉ EN TEMPS RÉEL', style: AppTheme.sans(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.red.shade300)),
          ]),
          const SizedBox(height: 8),
          Text('Sécurité & Urgences • Yaoundé, CM', style: AppTheme.serif(fontSize: 19)),
          const SizedBox(height: 6),
          Text("Services d'urgence nationaux, numéros directs et centres de santé les plus proches.",
              style: AppTheme.sans(fontSize: 11.5, color: AppColors.textMuted, height: 1.4)),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () => setState(() => sosActive = true),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red.shade600,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
              icon: const Icon(Icons.notifications_active, size: 17),
              label: Text("BOUTON D'ALERTE SOS", style: AppTheme.sans(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.white)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _alertsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          const Icon(Icons.warning_amber_rounded, size: 16, color: AppColors.gold),
          const SizedBox(width: 8),
          Text('Alertes & Vigilance Régionale', style: AppTheme.serif(fontSize: 14)),
        ]),
        const SizedBox(height: 12),
        ...widget.alerts.map((al) {
          final isWarning = al.type == SafetyAlertType.warning;
          final color = isWarning ? AppColors.warning : AppColors.info;
          return Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: color.withOpacity(0.3)),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(isWarning ? Icons.warning_amber_rounded : Icons.info_outline, size: 18, color: color),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(child: Text(al.title, style: AppTheme.sans(fontSize: 11.5, fontWeight: FontWeight.bold, color: Colors.white))),
                          Text(al.timeAgo, style: AppTheme.sans(fontSize: 9.5, color: AppColors.textMuted)),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(al.description, style: AppTheme.sans(fontSize: 11, color: AppColors.textMuted, height: 1.4)),
                    ],
                  ),
                ),
              ],
            ),
          );
        }),
      ],
    );
  }

  Widget _contactCard(EmergencyContact c) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: AppColors.border)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(color: Colors.red.withOpacity(0.1), borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.red.withOpacity(0.2))),
                    child: Icon(_iconFor(c.type), size: 18, color: Colors.red.shade300),
                  ),
                  Text(c.number, style: AppTheme.serif(fontSize: 20)),
                ],
              ),
              const SizedBox(height: 10),
              Text(c.name, style: AppTheme.sans(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.white)),
              const SizedBox(height: 4),
              Text(c.description, style: AppTheme.sans(fontSize: 10.5, color: AppColors.textMuted, height: 1.35)),
            ],
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () => setState(() => activeCall = c),
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.red.shade300,
                backgroundColor: Colors.red.withOpacity(0.15),
                side: BorderSide(color: Colors.red.withOpacity(0.4)),
                padding: const EdgeInsets.symmetric(vertical: 10),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              icon: const Icon(Icons.phone, size: 14),
              label: Text('APPELER LE ${c.number}', style: AppTheme.sans(fontSize: 10.5, fontWeight: FontWeight.bold, color: Colors.red.shade300)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _healthCard(HealthCenter hc) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(18), border: Border.all(color: AppColors.border)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(hc.status, style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.accent)),
              Text('${hc.distanceKm} km', style: AppTheme.sans(fontSize: 11, color: AppColors.textMuted)),
            ],
          ),
          const SizedBox(height: 6),
          Text(hc.name, style: AppTheme.sans(fontSize: 12.5, fontWeight: FontWeight.bold, color: Colors.white)),
          const SizedBox(height: 4),
          Row(children: [
            const Icon(Icons.location_on, size: 13, color: AppColors.accent),
            const SizedBox(width: 4),
            Expanded(child: Text(hc.address, style: AppTheme.sans(fontSize: 10.5, color: AppColors.textMuted))),
          ]),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Appel vers ${hc.name}: ${hc.phone}')));
              },
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.white,
                side: const BorderSide(color: AppColors.border),
                padding: const EdgeInsets.symmetric(vertical: 10),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              icon: const Icon(Icons.phone, size: 13, color: AppColors.accent),
              label: Text(hc.phone, style: AppTheme.sans(fontSize: 10.5, color: Colors.white)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _callModal(EmergencyContact c) {
    return Positioned.fill(
      child: Container(
        color: Colors.black.withOpacity(0.8),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 380),
            child: Container(
              margin: const EdgeInsets.all(20),
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(24), border: Border.all(color: Colors.red.withOpacity(0.5))),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 64,
                    height: 64,
                    decoration: BoxDecoration(color: Colors.red.withOpacity(0.2), shape: BoxShape.circle, border: Border.all(color: Colors.red.withOpacity(0.4))),
                    child: Icon(Icons.phone, size: 28, color: Colors.red.shade400),
                  ),
                  const SizedBox(height: 16),
                  Text('Appel en cours...', style: AppTheme.serif(fontSize: 18)),
                  const SizedBox(height: 4),
                  Text('${c.name} (${c.number})', style: AppTheme.sans(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.red.shade300)),
                  const SizedBox(height: 4),
                  Text('Liaison prioritaire avec le central de secours Yaoundé...', textAlign: TextAlign.center, style: AppTheme.sans(fontSize: 11, color: AppColors.textMuted)),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () => setState(() => activeCall = null),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red.shade600,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      child: Text('RACCROCHER', style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.white)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _sosModal() {
    return Positioned.fill(
      child: Container(
        color: Colors.black.withOpacity(0.85),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 420),
            child: Container(
              margin: const EdgeInsets.all(20),
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(24), border: Border.all(color: Colors.red)),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.shield, size: 48, color: Colors.red.shade400),
                  const SizedBox(height: 14),
                  Text('SIGNAL SOS TRANSMIS', style: AppTheme.serif(fontSize: 18)),
                  const SizedBox(height: 8),
                  Text(
                    'Vos coordonnées GPS actuelles (Yaoundé, CM) et vos informations médicales d\'urgence ont été transmises au central de secours 117.',
                    textAlign: TextAlign.center,
                    style: AppTheme.sans(fontSize: 11.5, color: AppColors.textMuted, height: 1.5),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () => setState(() => sosActive = false),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.accent,
                        foregroundColor: AppColors.bg,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      child: Text("FERMER L'ALERTE", style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.bg)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
