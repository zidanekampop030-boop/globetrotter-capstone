import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Image réseau haute définition, mise en cache, avec placeholder
/// shimmer léger et fallback propre en cas d'échec.
/// Equivalent Flutter de <img src=... className="object-cover" />
class HqNetworkImage extends StatelessWidget {
  final String url;
  final BoxFit fit;
  final int width;
  final int quality;
  final BorderRadius? borderRadius;

  const HqNetworkImage({
    super.key,
    required this.url,
    this.fit = BoxFit.cover,
    this.width = 1200,
    this.quality = 90,
    this.borderRadius,
  });

  @override
  Widget build(BuildContext context) {
    final img = CachedNetworkImage(
      imageUrl: hqImage(url, width: width, quality: quality),
      fit: fit,
      filterQuality: FilterQuality.high,
      fadeInDuration: const Duration(milliseconds: 250),
      placeholder: (context, _) => Container(
        color: AppColors.surfaceAlt,
        child: const Center(
          child: SizedBox(
            width: 22,
            height: 22,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              color: AppColors.accent,
            ),
          ),
        ),
      ),
      errorWidget: (context, _, __) => Container(
        color: AppColors.surfaceAlt,
        child: const Center(
          child: Icon(Icons.image_not_supported_outlined,
              color: AppColors.textMuted, size: 28),
        ),
      ),
    );

    if (borderRadius != null) {
      return ClipRRect(borderRadius: borderRadius!, child: img);
    }
    return img;
  }
}
