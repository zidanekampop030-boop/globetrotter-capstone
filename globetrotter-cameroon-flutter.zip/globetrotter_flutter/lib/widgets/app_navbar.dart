import 'package:flutter/material.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import 'hq_network_image.dart';

/// Equivalent Flutter de Navbar.tsx — en-tête sticky avec logo, navigation
/// desktop (affichée si l'écran est large), et actions (wishlist / urgences / profil).
class AppNavbar extends StatelessWidget implements PreferredSizeWidget {
  final String activeTab;
  final ValueChanged<String> setActiveTab;
  final int wishlistCount;
  final VoidCallback openEmergencyModal;
  final VoidCallback openAuthModal;
  final UserProfile? user;

  const AppNavbar({
    super.key,
    required this.activeTab,
    required this.setActiveTab,
    required this.wishlistCount,
    required this.openEmergencyModal,
    required this.openAuthModal,
    required this.user,
  });

  @override
  Size get preferredSize => const Size.fromHeight(66);

  static const _desktopLinks = [
    ('explore', 'Destinations', Icons.explore_outlined),
    ('transit', 'Transit & Tarifs', Icons.directions_bus_outlined),
    ('food', 'Cuisine', Icons.restaurant_outlined),
    ('regions', '10 Régions', Icons.map_outlined),
    ('journal', 'Carnet', Icons.menu_book_outlined),
  ];

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.of(context).size.width >= 900;

    return Container(
      decoration: const BoxDecoration(
        color: Color(0xE60C1419),
        border: Border(bottom: BorderSide(color: AppColors.border)),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(
            children: [
              // Logo & marque
              InkWell(
                onTap: () => setActiveTab('explore'),
                borderRadius: BorderRadius.circular(12),
                child: Row(
                  children: [
                    Container(
                      width: 40,
                      height: 40,
                      padding: const EdgeInsets.all(2),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        gradient: const LinearGradient(
                          colors: [AppColors.accentDeep, AppColors.accent, AppColors.gold],
                        ),
                      ),
                      child: Container(
                        decoration: const BoxDecoration(
                          color: AppColors.bg,
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        child: const Icon(Icons.explore, color: AppColors.accent, size: 20),
                      ),
                    ),
                    const SizedBox(width: 10),
                    if (isWide)
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text('GLOBETROTTER',
                                  style: AppTheme.serif(fontSize: 16, color: Colors.white)),
                              const SizedBox(width: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                decoration: BoxDecoration(
                                  color: AppColors.accentDeep.withOpacity(0.3),
                                  borderRadius: BorderRadius.circular(20),
                                  border: Border.all(color: AppColors.accentDeep.withOpacity(0.5)),
                                ),
                                child: Text('CAMEROUN',
                                    style: AppTheme.sans(
                                        fontSize: 10, fontWeight: FontWeight.w600, color: AppColors.accent)),
                              ),
                            ],
                          ),
                          Text('Patrimoine, Escapades & Gastronomie',
                              style: AppTheme.sans(fontSize: 10, color: AppColors.textMuted)),
                        ],
                      ),
                  ],
                ),
              ),

              const Spacer(),

              // Navigation desktop
              if (isWide)
                Container(
                  padding: const EdgeInsets.all(5),
                  margin: const EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Row(
                    children: _desktopLinks.map((l) {
                      final isActive = activeTab == l.$1;
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 2),
                        child: Material(
                          color: isActive ? AppColors.accent : Colors.transparent,
                          borderRadius: BorderRadius.circular(12),
                          child: InkWell(
                            borderRadius: BorderRadius.circular(12),
                            onTap: () => setActiveTab(l.$1),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                              child: Row(
                                children: [
                                  Icon(l.$3,
                                      size: 15,
                                      color: isActive ? AppColors.bg : AppColors.textMuted),
                                  const SizedBox(width: 6),
                                  Text(l.$2,
                                      style: AppTheme.sans(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w600,
                                        color: isActive ? AppColors.bg : AppColors.textMuted,
                                      )),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),

              // Actions
              Stack(
                clipBehavior: Clip.none,
                children: [
                  IconButton(
                    onPressed: () => setActiveTab('wishlist'),
                    style: IconButton.styleFrom(
                      backgroundColor: activeTab == 'wishlist' ? AppColors.border : AppColors.surface,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                        side: const BorderSide(color: AppColors.border),
                      ),
                    ),
                    icon: Icon(Icons.favorite_border,
                        size: 18,
                        color: activeTab == 'wishlist' ? AppColors.accent : AppColors.textMuted),
                  ),
                  if (wishlistCount > 0)
                    Positioned(
                      top: -2,
                      right: -2,
                      child: Container(
                        width: 16,
                        height: 16,
                        alignment: Alignment.center,
                        decoration: const BoxDecoration(color: AppColors.gold, shape: BoxShape.circle),
                        child: Text('$wishlistCount',
                            style: const TextStyle(
                                fontSize: 9, fontWeight: FontWeight.bold, color: AppColors.bg)),
                      ),
                    ),
                ],
              ),
              const SizedBox(width: 6),
              Material(
                color: Colors.red.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                child: InkWell(
                  borderRadius: BorderRadius.circular(12),
                  onTap: openEmergencyModal,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.red.withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.shield, size: 16, color: Colors.red.shade300),
                        if (isWide) ...[
                          const SizedBox(width: 6),
                          Text('Urgences 117',
                              style: AppTheme.sans(
                                  fontSize: 11, fontWeight: FontWeight.w600, color: Colors.red.shade300)),
                        ]
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 6),
              Material(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(12),
                child: InkWell(
                  borderRadius: BorderRadius.circular(12),
                  onTap: () => user != null ? setActiveTab('profile') : openAuthModal(),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: user != null
                        ? Row(
                            children: [
                              HqNetworkImage(
                                url: user!.avatarUrl,
                                width: 100,
                                borderRadius: BorderRadius.circular(20),
                              ).let((w) => SizedBox(width: 24, height: 24, child: w)),
                              if (isWide) ...[
                                const SizedBox(width: 8),
                                Text(user!.name.split(' ').first,
                                    style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.w600, color: Colors.white)),
                              ]
                            ],
                          )
                        : Row(
                            children: [
                              const Icon(Icons.person_outline, size: 16, color: AppColors.accent),
                              if (isWide) ...[
                                const SizedBox(width: 6),
                                Text('Connexion', style: AppTheme.sans(fontSize: 11, color: Colors.white)),
                              ]
                            ],
                          ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

extension _Let<T> on T {
  R let<R>(R Function(T) f) => f(this);
}
