import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class BottomNavTab {
  final String id;
  final String label;
  final IconData icon;
  final bool badge;
  const BottomNavTab(this.id, this.label, this.icon, {this.badge = false});
}

const List<BottomNavTab> _tabs = [
  BottomNavTab('explore', 'Explore', Icons.explore_outlined),
  BottomNavTab('transit', 'Transit', Icons.directions_bus_outlined),
  BottomNavTab('food', 'Cuisine', Icons.restaurant_outlined),
  BottomNavTab('regions', 'Régions', Icons.map_outlined),
  BottomNavTab('journal', 'Carnet', Icons.menu_book_outlined),
  BottomNavTab('safety', 'Urgences', Icons.shield_outlined, badge: true),
  BottomNavTab('profile', 'Profil', Icons.person_outline),
];

/// Equivalent Flutter de BottomNav.tsx — barre mobile fixe en bas d'écran
class BottomNav extends StatelessWidget {
  final String activeTab;
  final ValueChanged<String> onTabSelected;

  const BottomNav({super.key, required this.activeTab, required this.onTabSelected});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xF20C1419),
        border: Border(top: BorderSide(color: AppColors.border)),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
      child: SafeArea(
        top: false,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: _tabs.map((t) {
            final isActive = activeTab == t.id;
            final color = isActive ? AppColors.accent : AppColors.textMuted;
            return Expanded(
              child: InkWell(
                onTap: () => onTabSelected(t.id),
                borderRadius: BorderRadius.circular(14),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: isActive ? AppColors.accent.withOpacity(0.1) : null,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(
                          t.icon,
                          size: 20,
                          color: t.badge && !isActive ? Colors.red.shade300 : color,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        t.label,
                        style: TextStyle(
                          fontSize: 9.5,
                          fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
                          color: color,
                        ),
                      ),
                      if (isActive)
                        Container(
                          margin: const EdgeInsets.only(top: 2),
                          width: 4,
                          height: 4,
                          decoration: const BoxDecoration(
                            color: AppColors.accent,
                            shape: BoxShape.circle,
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}
