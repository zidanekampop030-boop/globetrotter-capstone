import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Palette de couleurs identique au thème Tailwind du projet React
/// (bg-[#0c1419], border-[#232b30], accent-[#79d8b7], gold-[#e4c199]...)
class AppColors {
  AppColors._();

  static const Color bg = Color(0xFF0C1419); // fond principal
  static const Color surface = Color(0xFF151D22); // cartes / panneaux
  static const Color surfaceAlt = Color(0xFF1F292E); // fonds secondaires
  static const Color surfaceChip = Color(0xFF1A2328);
  static const Color border = Color(0xFF232B30);
  static const Color borderLight = Color(0xFF2B363D);
  static const Color borderStrong = Color(0xFF323D44);

  static const Color textPrimary = Color(0xFFDBE4EB);
  static const Color textMuted = Color(0xFF8E9CA6);
  static const Color white = Color(0xFFFFFFFF);

  static const Color accent = Color(0xFF79D8B7); // vert menthe
  static const Color accentDark = Color(0xFF66C7A4);
  static const Color accentDeep = Color(0xFF007A5E); // vert profond
  static const Color gold = Color(0xFFE4C199); // or / beige
  static const Color goldDark = Color(0xFFD8B287);

  static const Color danger = Color(0xFFEF4444); // red-500
  static const Color dangerDark = Color(0xFFDC2626); // red-600
  static const Color warning = Color(0xFFF59E0B); // amber-500
  static const Color info = Color(0xFF3B82F6); // blue-500
  static const Color orange = Color(0xFFF97316); // Orange Money
  static const Color amber = Color(0xFFFBBF24); // MTN MoMo
}

class AppTheme {
  AppTheme._();

  static TextStyle serif({
    double fontSize = 16,
    FontWeight fontWeight = FontWeight.bold,
    Color color = AppColors.white,
    double? height,
    FontStyle? fontStyle,
  }) {
    return GoogleFonts.playfairDisplay(
      fontSize: fontSize,
      fontWeight: fontWeight,
      color: color,
      height: height,
      fontStyle: fontStyle,
    );
  }

  static TextStyle sans({
    double fontSize = 12,
    FontWeight fontWeight = FontWeight.normal,
    Color color = AppColors.textPrimary,
    double? height,
    double? letterSpacing,
  }) {
    return GoogleFonts.inter(
      fontSize: fontSize,
      fontWeight: fontWeight,
      color: color,
      height: height,
      letterSpacing: letterSpacing,
    );
  }

  static ThemeData get theme {
    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: AppColors.bg,
      colorScheme: ColorScheme.dark(
        primary: AppColors.accent,
        secondary: AppColors.gold,
        surface: AppColors.surface,
        error: AppColors.danger,
      ),
      fontFamily: GoogleFonts.inter().fontFamily,
      textTheme: GoogleFonts.interTextTheme(ThemeData.dark().textTheme),
      splashColor: AppColors.accent.withOpacity(0.1),
      highlightColor: Colors.transparent,
      dividerColor: AppColors.border,
    );
  }
}

/// Constructeur d'URL Unsplash haute qualité — force une largeur adaptée
/// et une qualité élevée pour un rendu "net comme Pinterest" quel que soit
/// l'écran (mobile / tablette / desktop), tout en gardant un cache mémoire
/// raisonnable.
String hqImage(String url, {int width = 1200, int quality = 90}) {
  if (!url.contains('images.unsplash.com')) return url;
  final uri = Uri.parse(url);
  final params = Map<String, String>.from(uri.queryParameters);
  params['auto'] = 'format';
  params['fit'] = 'crop';
  params['w'] = '$width';
  params['q'] = '$quality';
  return uri.replace(queryParameters: params).toString();
}
