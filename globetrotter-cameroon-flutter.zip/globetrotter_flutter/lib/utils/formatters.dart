import 'package:intl/intl.dart';

final NumberFormat _xafFormat = NumberFormat.decimalPattern('fr_FR');

/// Equivalent de `value.toLocaleString()` côté React (ex: 145000 -> "145 000")
String formatXAF(num value) => _xafFormat.format(value);
