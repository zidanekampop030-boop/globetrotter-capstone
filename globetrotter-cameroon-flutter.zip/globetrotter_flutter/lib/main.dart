import 'package:flutter/material.dart';
import 'data/mock_data.dart' as mock;
import 'models/models.dart';
import 'modals/auth_modal.dart';
import 'modals/availability_modal.dart';
import 'modals/payment_modal.dart';
import 'screens/explore_screen.dart';
import 'screens/food_screen.dart';
import 'screens/journal_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/regions_screen.dart';
import 'screens/safety_screen.dart';
import 'screens/transit_screen.dart';
import 'screens/wishlist_screen.dart';
import 'theme/app_theme.dart';
import 'widgets/app_navbar.dart';
import 'widgets/bottom_nav.dart';

void main() {
  runApp(const GlobeTrotterApp());
}

class GlobeTrotterApp extends StatelessWidget {
  const GlobeTrotterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'GlobeTrotter Cameroun',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.theme,
      home: const RootShell(),
    );
  }
}

/// Equivalent Flutter de App.tsx : détient tout l'état global de
/// l'application (données, onglet actif, modales, toasts) et orchestre
/// la navigation entre les écrans, exactement comme le composant React
/// racine le faisait avec useState / useEffect.
class RootShell extends StatefulWidget {
  const RootShell({super.key});

  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> {
  String activeTab = 'explore';

  // --- État des données (équivalent des useState de App.tsx) ---
  late List<Destination> destinations = mock.initialDestinations;
  late List<RegionInfo> regions = mock.regionsData;
  late List<Dish> dishes = mock.dishesData;
  late List<JournalPost> journalPosts = mock.journalPosts;
  late List<WishlistItem> wishlist = mock.initialWishlist;
  late List<EmergencyContact> emergencyContacts = mock.emergencyContacts;
  late List<HealthCenter> healthCenters = mock.healthCenters;
  late List<SafetyAlert> safetyAlerts = mock.safetyAlerts;
  UserProfile? user = mock.userProfileMock;

  String? _toastMessage;

  void _setActiveTab(String tab) => setState(() => activeTab = tab);

  void _showToast(String msg) {
    setState(() => _toastMessage = msg);
    Future.delayed(const Duration(seconds: 4), () {
      if (mounted && _toastMessage == msg) setState(() => _toastMessage = null);
    });
  }

  // --- Wishlist ---
  void _toggleWishlist(Destination dest) {
    final exists = wishlist.any((w) => w.title == dest.title);
    setState(() {
      if (exists) {
        wishlist = wishlist.where((w) => w.title != dest.title).toList();
      } else {
        final newItem = WishlistItem(
          id: 'wish-${DateTime.now().millisecondsSinceEpoch}',
          title: dest.title,
          type: WishlistType.destination,
          location: dest.location,
          imageUrl: dest.imageUrl,
          addedAt: "À l'instant",
          rating: dest.rating,
        );
        wishlist = [newItem, ...wishlist];
      }
    });
    _showToast(exists ? 'Retiré des souhaits: ${dest.title}' : 'Ajouté aux souhaits: ${dest.title}');
  }

  void _removeWishlist(String id) {
    setState(() => wishlist = wishlist.where((w) => w.id != id).toList());
    _showToast('Élément retiré de la liste de souhaits.');
  }

  // --- Journal ---
  void _addJournalPost(NewJournalEntry entry) {
    final newPost = JournalPost(
      id: 'j-${DateTime.now().millisecondsSinceEpoch}',
      title: entry.title,
      location: entry.location,
      date: "Aujourd'hui",
      author: user?.name ?? 'Marcelle Nkem',
      authorRole: 'Explorateur Passionné',
      authorAvatar: user?.avatarUrl ??
          'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
      coverImage: entry.coverImage ??
          'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=1200&q=85',
      excerpt: entry.content.length > 100 ? '${entry.content.substring(0, 100)}...' : entry.content,
      content: entry.content,
      likes: 1,
      commentsCount: 0,
    );
    setState(() => journalPosts = [newPost, ...journalPosts]);
    _showToast('Récit de voyage publié avec succès !');
  }

  // --- Paiement / Réservation ---
  void _initiatePayment(PayableItem item) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => PaymentModal(
        itemDescription: item.title,
        amountXAF: item.priceXAF,
        imageUrl: item.imageUrl,
        onSuccessPayment: () => _showToast('Réservation validée pour ${item.title} !'),
      ),
    );
  }

  void _openAuthModal() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.8),
      builder: (_) => AuthModal(
        onSuccessLogin: (u) {
          setState(() => user = u);
          _showToast('Bienvenue, ${u.name} !');
        },
      ),
    );
  }

  void _openAvailabilityModal() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.8),
      builder: (_) => AvailabilityModal(
        onConfirmDates: (dates) {
          _showToast('Dates appliquées: du ${dates.checkIn} au ${dates.checkOut} (${dates.guests} voyageurs)');
        },
      ),
    );
  }

  Widget _buildActiveScreen() {
    switch (activeTab) {
      case 'explore':
        return ExploreScreen(
          destinations: destinations,
          wishlistIds: wishlist.map((w) => w.id).toList(),
          onToggleWishlist: _toggleWishlist,
          onBookNow: _initiatePayment,
          onOpenAvailabilityModal: _openAvailabilityModal,
        );
      case 'transit':
        return const TransitScreen();
      case 'food':
        return FoodScreen(dishes: dishes, onOrderDish: _initiatePayment);
      case 'regions':
        return RegionsScreen(
          regions: regions,
          onSelectRegionExplore: (regionName) => _setActiveTab('explore'),
        );
      case 'journal':
        return JournalScreen(posts: journalPosts, onAddPost: _addJournalPost);
      case 'wishlist':
        return WishlistScreen(
          items: wishlist,
          onRemoveItem: _removeWishlist,
          onExploreLocation: (loc) => _setActiveTab('explore'),
        );
      case 'safety':
        return SafetyScreen(contacts: emergencyContacts, healthCenters: healthCenters, alerts: safetyAlerts);
      case 'profile':
        if (user == null) return const SizedBox.shrink();
        return ProfileScreen(
          user: user!,
          wishlistCount: wishlist.length,
          onNavigateTab: _setActiveTab,
          onLogout: () {
            setState(() => user = null);
            _showToast('Déconnexion réussie.');
          },
        );
      default:
        return const SizedBox.shrink();
    }
  }

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.of(context).size.width >= 900;

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppNavbar(
        activeTab: activeTab,
        setActiveTab: _setActiveTab,
        wishlistCount: wishlist.length,
        openEmergencyModal: () => _setActiveTab('safety'),
        openAuthModal: _openAuthModal,
        user: user,
      ),
      body: Stack(
        children: [
          Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 1280),
              child: _buildActiveScreen(),
            ),
          ),
          // Toast de notification globale (équivalent du bandeau React)
          if (_toastMessage != null)
            Positioned(
              top: 12,
              right: 16,
              left: 16,
              child: SafeArea(
                child: Align(
                  alignment: Alignment.topRight,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: AppColors.accent),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 16, offset: const Offset(0, 6))],
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.check_circle, size: 16, color: AppColors.accent),
                        const SizedBox(width: 8),
                        Flexible(child: Text(_toastMessage!, style: AppTheme.sans(fontSize: 11.5, color: Colors.white))),
                      ],
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
      bottomNavigationBar: isWide ? null : BottomNav(activeTab: activeTab, onTabSelected: _setActiveTab),
    );
  }
}
