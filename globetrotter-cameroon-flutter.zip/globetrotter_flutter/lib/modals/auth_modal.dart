import 'package:flutter/material.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';

/// Equivalent Flutter de AuthModal.tsx.
/// Affiché via showDialog() depuis main.dart.
class AuthModal extends StatefulWidget {
  final ValueChanged<UserProfile> onSuccessLogin;

  const AuthModal({super.key, required this.onSuccessLogin});

  @override
  State<AuthModal> createState() => _AuthModalState();
}

class _AuthModalState extends State<AuthModal> {
  bool isRegister = false;
  final _nameCtrl = TextEditingController(text: 'Marcelle Nkem');
  final _emailCtrl = TextEditingController(text: 'marcelle.nkem@example.cm');
  final _passwordCtrl = TextEditingController(text: '••••••••••••');
  bool showPassword = false;

  void _submit() {
    final name = isRegister ? _nameCtrl.text : 'Marcelle Nkem';
    widget.onSuccessLogin(UserProfile(
      id: 'usr-884',
      name: name,
      handle: '@${name.toLowerCase().replaceAll(' ', '_')}',
      avatarUrl:
          'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=85',
      bio: 'Explorateur passionné de la culture et du patrimoine camerounais.',
      statusTier: 'Voyageur Émérite OR 🏆',
      countriesVisited: 14,
      distanceKm: 12450,
      memoriesSaved: 842,
    ));
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.all(20),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 420),
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(24), border: Border.all(color: AppColors.border)),
          child: SingleChildScrollView(
            child: Column(
              children: [
                Row(
                  children: [
                    const Spacer(),
                    IconButton(
                      onPressed: () => Navigator.of(context).pop(),
                      icon: const Icon(Icons.close, size: 18, color: AppColors.textMuted),
                      style: IconButton.styleFrom(backgroundColor: AppColors.surfaceAlt),
                    ),
                  ],
                ),
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: AppColors.accentDeep.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.accent.withOpacity(0.4)),
                  ),
                  child: const Icon(Icons.explore, size: 22, color: AppColors.accent),
                ),
                const SizedBox(height: 10),
                Text(isRegister ? 'Créer un compte GlobeTrotter' : 'Bon retour parmi nous',
                    textAlign: TextAlign.center, style: AppTheme.serif(fontSize: 19)),
                const SizedBox(height: 6),
                Text('Accédez à vos réservations, itinéraires et carnets de voyage personnalisés.',
                    textAlign: TextAlign.center, style: AppTheme.sans(fontSize: 11, color: AppColors.textMuted)),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _submit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                    icon: const Icon(Icons.g_mobiledata, size: 22),
                    label: Text('Continuer avec Google', style: AppTheme.sans(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.black)),
                  ),
                ),
                const SizedBox(height: 16),
                Row(children: [
                  const Expanded(child: Divider(color: AppColors.border)),
                  Padding(padding: const EdgeInsets.symmetric(horizontal: 10), child: Text('ou par email', style: AppTheme.sans(fontSize: 11, color: AppColors.textMuted))),
                  const Expanded(child: Divider(color: AppColors.border)),
                ]),
                const SizedBox(height: 16),
                if (isRegister) ...[
                  _field('Nom complet', _nameCtrl, icon: Icons.person_outline, hint: 'Ex: Marcelle Nkem'),
                  const SizedBox(height: 12),
                ],
                _field('Adresse Email', _emailCtrl, icon: Icons.mail_outline, hint: 'votre.email@domaine.cm'),
                const SizedBox(height: 12),
                _field(
                  'Mot de passe',
                  _passwordCtrl,
                  icon: Icons.lock_outline,
                  obscure: !showPassword,
                  suffix: IconButton(
                    onPressed: () => setState(() => showPassword = !showPassword),
                    icon: Icon(showPassword ? Icons.visibility_off : Icons.visibility, size: 17, color: AppColors.textMuted),
                  ),
                ),
                const SizedBox(height: 18),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _submit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.accent,
                      foregroundColor: AppColors.bg,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    child: Text(isRegister ? 'CRÉER MON COMPTE' : 'SE CONNECTER',
                        style: AppTheme.sans(fontSize: 11.5, fontWeight: FontWeight.bold, color: AppColors.bg)),
                  ),
                ),
                const SizedBox(height: 14),
                TextButton(
                  onPressed: () => setState(() => isRegister = !isRegister),
                  child: Text(
                    isRegister ? 'Déjà un compte ? Connectez-vous' : 'Pas encore de compte ? Inscrivez-vous gratuitement',
                    style: AppTheme.sans(fontSize: 11.5, fontWeight: FontWeight.w600, color: AppColors.accent),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _field(String label, TextEditingController ctrl, {IconData? icon, String? hint, bool obscure = false, Widget? suffix}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: AppTheme.sans(fontSize: 11, color: AppColors.textMuted)),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(color: AppColors.bg, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
          child: TextField(
            controller: ctrl,
            obscureText: obscure,
            style: AppTheme.sans(fontSize: 12, color: Colors.white),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: AppTheme.sans(fontSize: 11.5, color: AppColors.textMuted),
              prefixIcon: icon != null ? Icon(icon, size: 16, color: AppColors.textMuted) : null,
              suffixIcon: suffix,
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(horizontal: 4, vertical: 12),
            ),
          ),
        ),
      ],
    );
  }
}
