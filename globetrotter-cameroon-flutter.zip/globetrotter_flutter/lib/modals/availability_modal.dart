import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class AvailabilityDates {
  final String checkIn;
  final String checkOut;
  final int guests;
  AvailabilityDates({required this.checkIn, required this.checkOut, required this.guests});
}

/// Equivalent Flutter de AvailabilityModal.tsx
class AvailabilityModal extends StatefulWidget {
  final ValueChanged<AvailabilityDates> onConfirmDates;

  const AvailabilityModal({super.key, required this.onConfirmDates});

  @override
  State<AvailabilityModal> createState() => _AvailabilityModalState();
}

class _AvailabilityModalState extends State<AvailabilityModal> {
  DateTime checkIn = DateTime(2026, 8, 15);
  DateTime checkOut = DateTime(2026, 8, 20);
  int guests = 2;

  String _fmt(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  Future<void> _pickDate({required bool isCheckIn}) async {
    final initial = isCheckIn ? checkIn : checkOut;
    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(2026, 1, 1),
      lastDate: DateTime(2027, 12, 31),
      builder: (context, child) => Theme(
        data: ThemeData.dark().copyWith(
          colorScheme: const ColorScheme.dark(primary: AppColors.accent, surface: AppColors.surface),
        ),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() {
        if (isCheckIn) {
          checkIn = picked;
        } else {
          checkOut = picked;
        }
      });
    }
  }

  void _submit() {
    widget.onConfirmDates(AvailabilityDates(checkIn: _fmt(checkIn), checkOut: _fmt(checkOut), guests: guests));
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.all(20),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 420),
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(24), border: Border.all(color: AppColors.border)),
          child: SingleChildScrollView(
            child: Column(
              children: [
                Row(children: [
                  const Spacer(),
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.close, size: 18, color: AppColors.textMuted),
                    style: IconButton.styleFrom(backgroundColor: AppColors.surfaceAlt),
                  ),
                ]),
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: AppColors.accentDeep.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.accent.withOpacity(0.4)),
                  ),
                  child: const Icon(Icons.calendar_today, size: 20, color: AppColors.accent),
                ),
                const SizedBox(height: 10),
                Text('Vérifier la Disponibilité', textAlign: TextAlign.center, style: AppTheme.serif(fontSize: 18)),
                const SizedBox(height: 6),
                Text('Sélectionnez vos dates de séjour dans nos lodges et villas du Cameroun.',
                    textAlign: TextAlign.center, style: AppTheme.sans(fontSize: 11, color: AppColors.textMuted)),
                const SizedBox(height: 20),
                Row(children: [
                  Expanded(child: _dateField("Date d'arrivée", checkIn, () => _pickDate(isCheckIn: true))),
                  const SizedBox(width: 10),
                  Expanded(child: _dateField('Date de départ', checkOut, () => _pickDate(isCheckIn: false))),
                ]),
                const SizedBox(height: 14),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Nombre de voyageurs', style: AppTheme.sans(fontSize: 11, color: AppColors.textMuted)),
                    const SizedBox(height: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      decoration: BoxDecoration(color: AppColors.bg, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
                      child: Row(children: [
                        const Icon(Icons.people_outline, size: 16, color: AppColors.textMuted),
                        const SizedBox(width: 8),
                        Expanded(
                          child: DropdownButtonHideUnderline(
                            child: DropdownButton<int>(
                              value: guests,
                              isExpanded: true,
                              dropdownColor: AppColors.surface,
                              style: AppTheme.sans(fontSize: 12, color: Colors.white),
                              items: List.generate(6, (i) => i + 1)
                                  .map((n) => DropdownMenuItem(value: n, child: Text('$n Voyageur${n > 1 ? 's' : ''}')))
                                  .toList(),
                              onChanged: (v) => setState(() => guests = v!),
                            ),
                          ),
                        ),
                      ]),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _submit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.accent,
                      foregroundColor: AppColors.bg,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    icon: const Icon(Icons.check, size: 16),
                    label: Text('APPLIQUER LES DATES DE SÉJOUR',
                        style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.bg)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _dateField(String label, DateTime value, VoidCallback onTap) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: AppTheme.sans(fontSize: 11, color: AppColors.textMuted)),
        const SizedBox(height: 6),
        InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
            decoration: BoxDecoration(color: AppColors.bg, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
            child: Text(_fmt(value), style: AppTheme.sans(fontSize: 12, color: Colors.white)),
          ),
        ),
      ],
    );
  }
}
