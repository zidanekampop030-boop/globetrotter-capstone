import 'dart:async';
import 'package:flutter/material.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import '../utils/formatters.dart';
import '../widgets/hq_network_image.dart';

enum _PaymentStep { form, processing, success }

/// Equivalent Flutter de PaymentModal.tsx — simulation Orange Money / MTN MoMo
class PaymentModal extends StatefulWidget {
  final String itemDescription;
  final int amountXAF;
  final String? imageUrl;
  final VoidCallback onSuccessPayment;

  const PaymentModal({
    super.key,
    required this.itemDescription,
    required this.amountXAF,
    this.imageUrl,
    required this.onSuccessPayment,
  });

  @override
  State<PaymentModal> createState() => _PaymentModalState();
}

class _PaymentModalState extends State<PaymentModal> {
  PaymentOperator operator = PaymentOperator.orangeMoney;
  final _phoneCtrl = TextEditingController(text: '699001122');
  _PaymentStep step = _PaymentStep.form;
  int secondsLeft = 120;
  bool showUssdHelp = true;
  Timer? _timer;

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  String get _ussdCode => operator == PaymentOperator.orangeMoney ? '#144#' : '*126#';

  void _initiate() {
    setState(() {
      secondsLeft = 120;
      step = _PaymentStep.processing;
    });
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      setState(() {
        if (secondsLeft <= 1) {
          secondsLeft = 0;
          t.cancel();
        } else {
          secondsLeft--;
        }
      });
    });
  }

  void _simulateConfirm() {
    _timer?.cancel();
    setState(() => step = _PaymentStep.success);
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        widget.onSuccessPayment();
        Navigator.of(context).pop();
      }
    });
  }

  String _formatTimer(int secs) {
    final m = secs ~/ 60;
    final s = secs % 60;
    return '${m < 10 ? '0' : ''}$m:${s < 10 ? '0' : ''}$s';
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.all(20),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 420),
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(24), border: Border.all(color: AppColors.border)),
          child: SingleChildScrollView(
            child: Column(
              children: [
                Row(children: [
                  const Spacer(),
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.close, size: 18, color: AppColors.textMuted),
                    style: IconButton.styleFrom(backgroundColor: AppColors.surfaceAlt),
                  ),
                ]),
                if (step == _PaymentStep.form) _formStep(),
                if (step == _PaymentStep.processing) _processingStep(),
                if (step == _PaymentStep.success) _successStep(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _formStep() {
    return Column(
      children: [
        Text('PAIEMENT MOBILE MONEY', style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.accent)),
        const SizedBox(height: 6),
        Text('Validation de Commande', style: AppTheme.serif(fontSize: 20)),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: AppColors.bg, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.border)),
          child: Row(children: [
            if (widget.imageUrl != null)
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: SizedBox(width: 48, height: 48, child: HqNetworkImage(url: widget.imageUrl!, width: 200)),
              ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(widget.itemDescription, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTheme.sans(fontSize: 11.5, fontWeight: FontWeight.bold, color: Colors.white)),
                  Text('Total à régler:', style: AppTheme.sans(fontSize: 10.5, color: AppColors.textMuted)),
                ],
              ),
            ),
            Text('${formatXAF(widget.amountXAF)} XAF', style: AppTheme.serif(fontSize: 15, color: AppColors.accent)),
          ]),
        ),
        const SizedBox(height: 18),
        Align(
          alignment: Alignment.centerLeft,
          child: Text('Choisissez votre Opérateur', style: AppTheme.sans(fontSize: 11, color: AppColors.textMuted)),
        ),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: _operatorButton(PaymentOperator.orangeMoney, 'Orange Money', 'Code #144#', AppColors.orange)),
          const SizedBox(width: 10),
          Expanded(child: _operatorButton(PaymentOperator.mtnMomo, 'MTN MoMo', 'Code *126#', AppColors.amber)),
        ]),
        const SizedBox(height: 14),
        Align(
          alignment: Alignment.centerLeft,
          child: Text('Numéro de Téléphone (+237)', style: AppTheme.sans(fontSize: 11, color: AppColors.textMuted)),
        ),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(color: AppColors.bg, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
          child: TextField(
            controller: _phoneCtrl,
            keyboardType: TextInputType.phone,
            style: AppTheme.sans(fontSize: 12, color: Colors.white, letterSpacing: 1),
            decoration: InputDecoration(
              hintText: '6XX XXX XXX',
              hintStyle: AppTheme.sans(fontSize: 12, color: AppColors.textMuted),
              prefixText: '+237  ',
              prefixStyle: AppTheme.sans(fontSize: 12, fontWeight: FontWeight.bold, color: AppColors.textMuted),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
            ),
          ),
        ),
        const SizedBox(height: 20),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: _initiate,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.accent,
              foregroundColor: AppColors.bg,
              padding: const EdgeInsets.symmetric(vertical: 15),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            ),
            icon: const Icon(Icons.verified_user, size: 16),
            label: Text('PAYER MAINTENANT (${formatXAF(widget.amountXAF)} XAF)',
                style: AppTheme.sans(fontSize: 11.5, fontWeight: FontWeight.bold, color: AppColors.bg)),
          ),
        ),
      ],
    );
  }

  Widget _operatorButton(PaymentOperator op, String label, String code, Color color) {
    final isSelected = operator == op;
    return InkWell(
      onTap: () => setState(() => this.operator = op),
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isSelected ? color.withOpacity(0.12) : AppColors.bg,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: isSelected ? color : AppColors.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Container(width: 10, height: 10, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
              const SizedBox(width: 6),
              Expanded(child: Text(label, style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.white))),
            ]),
            const SizedBox(height: 4),
            Text(code, style: AppTheme.sans(fontSize: 9.5, color: color)),
          ],
        ),
      ),
    );
  }

  Widget _processingStep() {
    return Column(
      children: [
        Container(
          width: 64,
          height: 64,
          decoration: BoxDecoration(color: AppColors.accent.withOpacity(0.1), shape: BoxShape.circle, border: Border.all(color: AppColors.accent.withOpacity(0.4))),
          child: const Padding(
            padding: EdgeInsets.all(16),
            child: CircularProgressIndicator(strokeWidth: 2.5, color: AppColors.accent),
          ),
        ),
        const SizedBox(height: 16),
        Text('VALIDATION EN COURS', style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.accent)),
        const SizedBox(height: 4),
        Text('Attente de Confirmation USSD', style: AppTheme.serif(fontSize: 18)),
        const SizedBox(height: 8),
        Text.rich(
          TextSpan(
            style: AppTheme.sans(fontSize: 11.5, color: AppColors.textMuted),
            children: [
              const TextSpan(text: 'Une notification de paiement sécurisée a été envoyée au mobile '),
              TextSpan(text: '+237 ${_phoneCtrl.text}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              const TextSpan(text: '.'),
            ],
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: AppColors.bg, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.border)),
          child: Column(children: [
            Text('TEMPS RESTANT POUR VALIDER', style: AppTheme.sans(fontSize: 9.5, color: AppColors.textMuted)),
            const SizedBox(height: 4),
            Text(_formatTimer(secondsLeft), style: AppTheme.sans(fontSize: 28, fontWeight: FontWeight.bold, color: AppColors.gold)),
          ]),
        ),
        const SizedBox(height: 14),
        Container(
          decoration: BoxDecoration(color: AppColors.surfaceAlt, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.borderLight)),
          child: Column(
            children: [
              InkWell(
                onTap: () => setState(() => showUssdHelp = !showUssdHelp),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Text(
                          'Instructions ${operator == PaymentOperator.orangeMoney ? 'Orange Money' : 'MTN MoMo'}',
                          style: AppTheme.sans(fontSize: 11.5, fontWeight: FontWeight.bold, color: Colors.white),
                        ),
                      ),
                      Icon(showUssdHelp ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down, color: AppColors.textMuted),
                    ],
                  ),
                ),
              ),
              if (showUssdHelp)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
                  decoration: const BoxDecoration(border: Border(top: BorderSide(color: AppColors.borderLight))),
                  child: Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('1. Composez le $_ussdCode sur votre téléphone.', style: AppTheme.sans(fontSize: 10.5, color: AppColors.textMuted)),
                        const SizedBox(height: 4),
                        Text('2. Saisissez votre code secret Mobile Money.', style: AppTheme.sans(fontSize: 10.5, color: AppColors.textMuted)),
                        const SizedBox(height: 4),
                        Text('3. Confirmez le débit de ${formatXAF(widget.amountXAF)} XAF.', style: AppTheme.sans(fontSize: 10.5, color: AppColors.textMuted)),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: _simulateConfirm,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.accent,
              foregroundColor: AppColors.bg,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            icon: const Icon(Icons.check_circle, size: 16),
            label: Text('SIMULER LA VALIDATION (DEMO)', style: AppTheme.sans(fontSize: 10.5, fontWeight: FontWeight.bold, color: AppColors.bg)),
          ),
        ),
        const SizedBox(height: 10),
        TextButton(
          onPressed: () {
            _timer?.cancel();
            setState(() => step = _PaymentStep.form);
          },
          child: Text('Annuler la transaction', style: AppTheme.sans(fontSize: 11, fontWeight: FontWeight.w600, color: Colors.red.shade300)),
        ),
      ],
    );
  }

  Widget _successStep() {
    return Column(
      children: [
        const SizedBox(height: 10),
        Container(
          width: 72,
          height: 72,
          decoration: BoxDecoration(color: AppColors.accentDeep.withOpacity(0.3), shape: BoxShape.circle, border: Border.all(color: AppColors.accent)),
          child: const Icon(Icons.check_circle, size: 40, color: AppColors.accent),
        ),
        const SizedBox(height: 16),
        Text('Transaction Réussie !', style: AppTheme.serif(fontSize: 20)),
        const SizedBox(height: 8),
        Text.rich(
          TextSpan(
            style: AppTheme.sans(fontSize: 11.5, color: AppColors.textMuted),
            children: [
              const TextSpan(text: 'Votre paiement de '),
              TextSpan(text: '${formatXAF(widget.amountXAF)} XAF', style: const TextStyle(color: AppColors.accent, fontWeight: FontWeight.bold)),
              const TextSpan(text: ' a été validé. Un reçu électronique a été envoyé à votre compte.'),
            ],
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 10),
      ],
    );
  }
}
