import json
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

DATA_DIR = Path(__file__).resolve().parent.parent / "data"


@pytest.fixture(autouse=True)
def reset_data_files():
    """Réinitialise users.json et itineraries.json avant chaque test pour
    garder des tests indépendants les uns des autres."""
    (DATA_DIR / "users.json").write_text("[]", encoding="utf-8")
    (DATA_DIR / "itineraries.json").write_text("[]", encoding="utf-8")
    yield
    (DATA_DIR / "users.json").write_text("[]", encoding="utf-8")
    (DATA_DIR / "itineraries.json").write_text("[]", encoding="utf-8")


@pytest.fixture
def client():
    from app.main import app
    return TestClient(app)


def test_health(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_register_and_login(client):
    register_resp = client.post(
        "/register",
        json={"email": "alice@example.com", "full_name": "Alice", "password": "secret123"},
    )
    assert register_resp.status_code == 201
    assert register_resp.json()["email"] == "alice@example.com"

    # Email déjà utilisé -> 400
    duplicate_resp = client.post(
        "/register",
        json={"email": "alice@example.com", "full_name": "Alice", "password": "secret123"},
    )
    assert duplicate_resp.status_code == 400

    login_resp = client.post(
        "/login", json={"email": "alice@example.com", "password": "secret123"}
    )
    assert login_resp.status_code == 200
    assert "access_token" in login_resp.json()

    # Mauvais mot de passe -> 401
    bad_login_resp = client.post(
        "/login", json={"email": "alice@example.com", "password": "wrong"}
    )
    assert bad_login_resp.status_code == 401


def test_destinations_search(client):
    response = client.get("/destinations", params={"country": "Cameroun"})
    assert response.status_code == 200
    results = response.json()
    assert len(results) > 0
    assert all(d["country"] == "Cameroun" for d in results)


def test_itineraries_require_auth(client):
    response = client.post(
        "/itineraries",
        json={"destination_id": 1, "start_date": "2026-08-01", "end_date": "2026-08-10"},
    )
    assert response.status_code == 401


def test_create_itinerary_and_get_recommendations(client):
    client.post(
        "/register",
        json={"email": "bob@example.com", "full_name": "Bob", "password": "secret123"},
    )
    login_resp = client.post("/login", json={"email": "bob@example.com", "password": "secret123"})
    token = login_resp.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    itinerary_resp = client.post(
        "/itineraries",
        json={"destination_id": 1, "start_date": "2026-08-01", "end_date": "2026-08-10"},
        headers=headers,
    )
    assert itinerary_resp.status_code == 201
    assert itinerary_resp.json()["destination_id"] == 1

    my_itineraries_resp = client.get("/itineraries", headers=headers)
    assert my_itineraries_resp.status_code == 200
    assert len(my_itineraries_resp.json()) == 1

    recommendations_resp = client.get("/recommendations", headers=headers)
    assert recommendations_resp.status_code == 200
    assert len(recommendations_resp.json()) > 0
