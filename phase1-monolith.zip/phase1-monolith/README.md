# GlobeTrotter API — Phase 1 (Monolith)

Monolithe FastAPI unique regroupant l'authentification, le catalogue de
destinations, les recommandations personnalisées et les itinéraires.
Stockage sur fichiers JSON (`data/`) — aucune base de données en Phase 1.

## Project Structure

```
.
├── app/
│   ├── __init__.py
│   ├── models.py           # modèles Pydantic partagés
│   ├── auth.py              # register / login / JWT
│   ├── destinations.py      # catalogue de destinations
│   ├── recommendations.py   # recommandations personnalisées
│   ├── itineraries.py       # itinéraires de l'utilisateur
│   └── main.py               # point d'entrée FastAPI
├── data/
│   ├── destinations.json
│   ├── users.json
│   └── itineraries.json
├── tests/
│   └── test_api.py
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
└── README.md
```

## REST API

| Method | Endpoint          | Auth required | Description                     |
|--------|-------------------|----------------|----------------------------------|
| POST   | `/register`       | No             | Register a new user              |
| POST   | `/login`          | No             | Authenticate and receive a JWT   |
| GET    | `/destinations`   | No             | Search the destination catalogue |
| GET    | `/recommendations`| Yes (JWT)      | Get personalised recommendations |
| POST   | `/itineraries`    | Yes (JWT)      | Create a new itinerary           |
| GET    | `/itineraries`    | Yes (JWT)      | List my itineraries              |
| GET    | `/health`         | No             | Health check                     |

## Lancer le projet

```bash
docker compose up --build
# Documentation interactive : http://localhost:8000/docs
```

## Lancer les tests

```bash
pip install -r requirements.txt
pytest tests/ -v
```

## Exemple d'utilisation

```bash
# 1. S'inscrire
curl -X POST http://localhost:8000/register \
  -H "Content-Type: application/json" \
  -d '{"email":"alice@example.com","full_name":"Alice","password":"secret123"}'

# 2. Se connecter (récupérer un token JWT)
TOKEN=$(curl -s -X POST http://localhost:8000/login \
  -H "Content-Type: application/json" \
  -d '{"email":"alice@example.com","password":"secret123"}' | jq -r .access_token)

# 3. Chercher des destinations (public)
curl "http://localhost:8000/destinations?country=Cameroun"

# 4. Créer un itinéraire (protégé)
curl -X POST http://localhost:8000/itineraries \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"destination_id":1,"start_date":"2026-08-01","end_date":"2026-08-10"}'

# 5. Obtenir des recommandations personnalisées (protégé)
curl http://localhost:8000/recommendations -H "Authorization: Bearer $TOKEN"
```

## Limites de cette architecture (à résoudre en Phase 2)

- **Couplage fort** : `auth.py`, `destinations.py`, `recommendations.py` et
  `itineraries.py` importent tous directement `models.py` et se lisent/
  s'écrivent parfois entre eux (`recommendations.py` lit les itinéraires).
  Un changement de format dans un module peut casser les autres.
- **Scalabilité globale uniquement** : impossible de scaler uniquement
  `/recommendations` (potentiellement coûteux en calcul) sans scaler tout
  le monolithe.
- **Stockage fichier non concurrent-safe** : plusieurs requêtes simultanées
  en écriture sur `users.json` peuvent se marcher dessus — acceptable pour
  une démo Phase 1, mais une vraie raison de plus de passer à des bases de
  données dédiées par service en Phase 2.
