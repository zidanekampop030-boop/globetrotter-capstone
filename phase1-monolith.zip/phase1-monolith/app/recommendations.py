"""
Recommandations personnalisées. Protégé par JWT (l'utilisateur doit être
connecté). La logique reste volontairement simple en Phase 1 : elle se
base sur l'historique d'itinéraires de l'utilisateur (destinations déjà
visitées/planifiées) pour suggérer des destinations aux tags similaires.
"""

import json
from pathlib import Path

from fastapi import APIRouter, Depends

from .auth import get_current_user
from .destinations import load_destinations
from .models import RecommendationOut, Destination

router = APIRouter(tags=["recommendations"])

ITINERARIES_FILE = Path(__file__).resolve().parent.parent / "data" / "itineraries.json"


def _load_itineraries() -> list[dict]:
    if not ITINERARIES_FILE.exists():
        return []
    with open(ITINERARIES_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def _user_preferred_tags(user_id: int, destinations: list[dict]) -> set[str]:
    """Déduit les tags préférés d'un utilisateur à partir des destinations
    associées à ses itinéraires existants."""
    itineraries = _load_itineraries()
    by_id = {d["id"]: d for d in destinations}

    tags: set[str] = set()
    for itinerary in itineraries:
        if itinerary["user_id"] != user_id:
            continue
        dest = by_id.get(itinerary["destination_id"])
        if dest:
            tags.update(dest.get("tags", []))
    return tags


@router.get("/recommendations", response_model=list[RecommendationOut])
def get_recommendations(current_user: dict = Depends(get_current_user), limit: int = 5):
    destinations = load_destinations()
    preferred_tags = _user_preferred_tags(current_user["id"], destinations)

    scored = []
    for dest in destinations:
        dest_tags = set(dest.get("tags", []))
        overlap = dest_tags & preferred_tags
        if preferred_tags:
            score = len(overlap) / len(preferred_tags)
            reason = (
                f"Correspond à vos goûts ({', '.join(overlap)})"
                if overlap else "Peut élargir vos horizons"
            )
        else:
            # Nouvel utilisateur sans historique : on renvoie les moins chères en premier.
            score = 1.0 / (1.0 + dest["avg_price_usd"] / 1000)
            reason = "Suggestion de découverte (destination économique)"

        scored.append(
            RecommendationOut(destination=Destination(**dest), score=round(score, 3), reason=reason)
        )

    scored.sort(key=lambda r: r.score, reverse=True)
    return scored[:limit]
