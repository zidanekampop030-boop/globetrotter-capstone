from fastapi import FastAPI

from . import auth, destinations, recommendations, itineraries

# Monolithe : un seul processus FastAPI expose tous les modules
# (auth, destinations, recommendations, itineraries). Ils partagent le
# même cycle de vie, le même déploiement, et les mêmes ressources.
app = FastAPI(
    title="GlobeTrotter API - Phase 1 (Monolith)",
    description="Recherche de destinations, recommandations personnalisées et itinéraires.",
    version="1.0.0",
)

app.include_router(auth.router)
app.include_router(destinations.router)
app.include_router(recommendations.router)
app.include_router(itineraries.router)


@app.get("/health", tags=["health"])
def health():
    return {"status": "ok", "service": "globetrotter-monolith"}
