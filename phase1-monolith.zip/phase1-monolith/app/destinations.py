"""
Catalogue de destinations. Lecture seule depuis data/destinations.json.
Endpoint public (pas d'authentification requise).
"""

import json
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Query

from .models import Destination

router = APIRouter(tags=["destinations"])

DATA_FILE = Path(__file__).resolve().parent.parent / "data" / "destinations.json"


def load_destinations() -> list[dict]:
    if not DATA_FILE.exists():
        return []
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


@router.get("/destinations", response_model=list[Destination])
def search_destinations(
    country: Optional[str] = Query(default=None, description="Filtrer par pays"),
    tag: Optional[str] = Query(default=None, description="Filtrer par tag (ex: plage, montagne)"),
    max_price: Optional[float] = Query(default=None, description="Prix moyen maximum en USD"),
):
    destinations = load_destinations()

    if country:
        destinations = [d for d in destinations if d["country"].lower() == country.lower()]
    if tag:
        destinations = [d for d in destinations if tag.lower() in [t.lower() for t in d.get("tags", [])]]
    if max_price is not None:
        destinations = [d for d in destinations if d["avg_price_usd"] <= max_price]

    return destinations
