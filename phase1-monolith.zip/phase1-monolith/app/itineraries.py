"""
Itinéraires personnels de l'utilisateur connecté. Protégé par JWT.
Persisté dans data/itineraries.json.
"""

import json
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, status

from .auth import get_current_user
from .destinations import load_destinations
from .models import ItineraryCreate, ItineraryOut

router = APIRouter(tags=["itineraries"])

DATA_FILE = Path(__file__).resolve().parent.parent / "data" / "itineraries.json"


def _load_itineraries() -> list[dict]:
    if not DATA_FILE.exists():
        return []
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def _save_itineraries(itineraries: list[dict]) -> None:
    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(itineraries, f, indent=2)


def _next_id(itineraries: list[dict]) -> int:
    return max((i["id"] for i in itineraries), default=0) + 1


@router.post("/itineraries", response_model=ItineraryOut, status_code=status.HTTP_201_CREATED)
def create_itinerary(payload: ItineraryCreate, current_user: dict = Depends(get_current_user)):
    destinations = load_destinations()
    if not any(d["id"] == payload.destination_id for d in destinations):
        raise HTTPException(status_code=404, detail="Destination not found")

    itineraries = _load_itineraries()
    new_itinerary = {
        "id": _next_id(itineraries),
        "user_id": current_user["id"],
        "destination_id": payload.destination_id,
        "start_date": payload.start_date,
        "end_date": payload.end_date,
        "notes": payload.notes,
    }
    itineraries.append(new_itinerary)
    _save_itineraries(itineraries)
    return ItineraryOut(**new_itinerary)


@router.get("/itineraries", response_model=list[ItineraryOut])
def list_my_itineraries(current_user: dict = Depends(get_current_user)):
    itineraries = _load_itineraries()
    return [ItineraryOut(**i) for i in itineraries if i["user_id"] == current_user["id"]]
