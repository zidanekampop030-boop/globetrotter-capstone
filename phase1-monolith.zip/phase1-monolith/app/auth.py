"""
Authentification : inscription, connexion, émission et vérification de
JWT. Les utilisateurs sont persistés dans data/users.json (pas de base
de données en Phase 1 : stockage fichier volontairement simple).
"""

import json
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from passlib.context import CryptContext

from .models import UserRegister, UserLogin, UserOut, TokenResponse

router = APIRouter(tags=["auth"])

DATA_FILE = Path(__file__).resolve().parent.parent / "data" / "users.json"

SECRET_KEY = os.getenv("JWT_SECRET_KEY", "dev-secret-change-me-in-production")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login", auto_error=False)


# ---------- Stockage fichier ----------

def _load_users() -> list[dict]:
    if not DATA_FILE.exists():
        return []
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def _save_users(users: list[dict]) -> None:
    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(users, f, indent=2)


def _next_id(users: list[dict]) -> int:
    return max((u["id"] for u in users), default=0) + 1


# ---------- Sécurité ----------

def _hash_password(password: str) -> str:
    return pwd_context.hash(password)


def _verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(plain, hashed)


def create_access_token(user_id: int, email: str) -> str:
    expire = datetime.now(timezone.utc) + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    payload = {"sub": str(user_id), "email": email, "exp": expire}
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


def get_current_user(token: str = Depends(oauth2_scheme)) -> dict:
    credentials_error = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    if token is None:
        raise credentials_error
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = int(payload.get("sub"))
    except (JWTError, TypeError, ValueError):
        raise credentials_error

    users = _load_users()
    user = next((u for u in users if u["id"] == user_id), None)
    if user is None:
        raise credentials_error
    return user


# ---------- Routes ----------

@router.post("/register", response_model=UserOut, status_code=status.HTTP_201_CREATED)
def register(payload: UserRegister):
    users = _load_users()
    if any(u["email"] == payload.email for u in users):
        raise HTTPException(status_code=400, detail="Email already registered")

    new_user = {
        "id": _next_id(users),
        "email": payload.email,
        "full_name": payload.full_name,
        "hashed_password": _hash_password(payload.password),
    }
    users.append(new_user)
    _save_users(users)
    return UserOut(id=new_user["id"], email=new_user["email"], full_name=new_user["full_name"])


@router.post("/login", response_model=TokenResponse)
def login(payload: UserLogin):
    users = _load_users()
    user = next((u for u in users if u["email"] == payload.email), None)
    if not user or not _verify_password(payload.password, user["hashed_password"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    token = create_access_token(user_id=user["id"], email=user["email"])
    return TokenResponse(access_token=token)
