"""
Modèles de données partagés par TOUS les modules du monolithe
(auth, destinations, recommendations, itineraries).

C'est justement ce partage direct de modèles entre modules, à l'intérieur
d'un seul et même processus, qui illustre le couplage fort de la Phase 1 :
toute modification d'un modèle ici impacte potentiellement auth.py,
destinations.py, recommendations.py ET itineraries.py en même temps.
"""

from typing import Optional
from pydantic import BaseModel, EmailStr, Field


# ---------- Auth / Users ----------

class UserRegister(BaseModel):
    email: EmailStr
    full_name: str
    password: str


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    id: int
    email: EmailStr
    full_name: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


# ---------- Destinations ----------

class Destination(BaseModel):
    id: int
    name: str
    country: str
    tags: list[str] = Field(default_factory=list)
    avg_price_usd: float
    description: str


# ---------- Recommendations ----------

class RecommendationOut(BaseModel):
    destination: Destination
    score: float
    reason: str


# ---------- Itineraries ----------

class ItineraryCreate(BaseModel):
    destination_id: int
    start_date: str
    end_date: str
    notes: Optional[str] = None


class ItineraryOut(BaseModel):
    id: int
    user_id: int
    destination_id: int
    start_date: str
    end_date: str
    notes: Optional[str] = None
